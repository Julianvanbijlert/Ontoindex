"use client"

import { useState, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import {
  Globe,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Download,
  Search,
  ChevronDown,
  ChevronRight,
  StopCircle,
  ExternalLink,
  Layers,
} from "lucide-react"
import type { ParsedTerm } from "@/app/api/parse-url/route"
import type { CrawlLink } from "@/app/api/crawl/route"

type UrlImportProps = {
  onImport: (terms: ParsedTerm[], pageTitle: string, sourceUrl: string) => void
  isProcessing: boolean
}

type ParseResult = {
  url: string
  pageTitle: string
  pageDescription: string
  termCount: number
  terms: ParsedTerm[]
}

type CrawlPage = {
  url: string
  label: string
  context: string
  status: "pending" | "crawling" | "parsing" | "done" | "error"
  termCount: number
  error?: string
}

type CrawlState = {
  status: "idle" | "discovering" | "parsing" | "done" | "stopped"
  pages: CrawlPage[]
  allTerms: ParsedTerm[]
  totalParsed: number
  totalDiscovered: number
  rootTitle: string
}

export function UrlImport({ onImport, isProcessing }: UrlImportProps) {
  const [url, setUrl] = useState("")
  const [maxDepth, setMaxDepth] = useState(3)
  const [maxPages, setMaxPages] = useState(50)
  const [error, setError] = useState<string | null>(null)
  const [crawlState, setCrawlState] = useState<CrawlState>({
    status: "idle",
    pages: [],
    allTerms: [],
    totalParsed: 0,
    totalDiscovered: 0,
    rootTitle: "",
  })
  const [selectedTermIds, setSelectedTermIds] = useState<Set<string>>(new Set())
  const [filterQuery, setFilterQuery] = useState("")
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set())
  const [showPages, setShowPages] = useState(false)
  const abortRef = useRef(false)

  // ── Crawl orchestration ──
  const startCrawl = useCallback(async () => {
    if (!url.trim()) return
    abortRef.current = false
    setError(null)
    setSelectedTermIds(new Set())
    setFilterQuery("")

    const visited = new Set<string>()
    const queue: { url: string; label: string; context: string; depth: number }[] = []
    const allTerms: ParsedTerm[] = []
    const pages: CrawlPage[] = []
    let rootTitle = ""

    // Normalize URL for dedup
    function normalize(u: string): string {
      try {
        const parsed = new URL(u)
        parsed.hash = ""
        let n = parsed.toString()
        if (n.endsWith("/") && n !== parsed.origin + "/") n = n.slice(0, -1)
        return n
      } catch {
        return u
      }
    }

    const startUrl = normalize(url.trim())
    visited.add(startUrl)
    queue.push({ url: startUrl, label: "Start page", context: "root", depth: 0 })

    const baseDomain = new URL(startUrl).origin

    setCrawlState({
      status: "discovering",
      pages: [],
      allTerms: [],
      totalParsed: 0,
      totalDiscovered: 1,
      rootTitle: "",
    })

    while (queue.length > 0 && !abortRef.current) {
      const current = queue.shift()!

      if (pages.length >= maxPages) break

      // Update page status
      const pageEntry: CrawlPage = {
        url: current.url,
        label: current.label,
        context: current.context,
        status: "crawling",
        termCount: 0,
      }
      pages.push(pageEntry)

      setCrawlState((prev) => ({
        ...prev,
        status: "discovering",
        pages: [...pages],
        totalDiscovered: visited.size,
      }))

      // 1. Discover links from this page (only if within depth limit)
      if (current.depth < maxDepth) {
        try {
          const crawlRes = await fetch("/api/crawl", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: current.url, baseDomain }),
          })
          if (crawlRes.ok) {
            const crawlData = await crawlRes.json()
            if (current.depth === 0) {
              rootTitle = crawlData.pageTitle || "Crawled Site"
            }

            // Add discovered links to queue
            const newLinks: CrawlLink[] = crawlData.links || []
            for (const link of newLinks) {
              const normalizedLink = normalize(link.url)
              if (!visited.has(normalizedLink) && visited.size < maxPages) {
                visited.add(normalizedLink)
                queue.push({
                  url: normalizedLink,
                  label: link.label,
                  context: link.context,
                  depth: current.depth + 1,
                })
              }
            }

            setCrawlState((prev) => ({
              ...prev,
              totalDiscovered: visited.size,
              rootTitle: rootTitle || prev.rootTitle,
            }))
          }
        } catch {
          // crawl discovery failed, still try to parse
        }
      }

      if (abortRef.current) break

      // 2. Parse terms from this page
      pageEntry.status = "parsing"
      setCrawlState((prev) => ({
        ...prev,
        status: "parsing",
        pages: [...pages],
      }))

      try {
        const parseRes = await fetch("/api/parse-url", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: current.url }),
        })

        if (parseRes.ok) {
          const parseData: ParseResult = await parseRes.json()
          // Add source page info to terms and deduplicate
          const pageTerms = parseData.terms.map((t) => ({
            ...t,
            id: `${current.url}-${t.id}`, // ensure uniqueness across pages
            sourceUrl: current.url,
            section: t.section || current.label || parseData.pageTitle || "",
          }))

          allTerms.push(...pageTerms)
          pageEntry.termCount = parseData.termCount || parseData.terms.length
          pageEntry.status = "done"
        } else {
          pageEntry.status = "error"
          pageEntry.error = "Parse failed"
        }
      } catch (err) {
        pageEntry.status = "error"
        pageEntry.error = err instanceof Error ? err.message : "Network error"
      }

      setCrawlState((prev) => ({
        ...prev,
        pages: [...pages],
        allTerms: [...allTerms],
        totalParsed: pages.filter((p) => p.status === "done").length,
      }))
    }

    // Deduplicate terms across pages by label+uri
    const seen = new Set<string>()
    const dedupedTerms: ParsedTerm[] = []
    for (const term of allTerms) {
      const key = `${term.label.toLowerCase()}||${term.uri.toLowerCase()}`
      if (seen.has(key)) continue
      seen.add(key)
      dedupedTerms.push(term)
    }

    setCrawlState({
      status: abortRef.current ? "stopped" : "done",
      pages: [...pages],
      allTerms: dedupedTerms,
      totalParsed: pages.filter((p) => p.status === "done").length,
      totalDiscovered: visited.size,
      rootTitle,
    })

    // Select all by default
    setSelectedTermIds(new Set(dedupedTerms.map((t) => t.id)))
    const sections = new Set(dedupedTerms.map((t) => t.section || "Uncategorized"))
    setExpandedSections(sections)

    if (dedupedTerms.length === 0) {
      setError(
        "No terms were found across all crawled pages. The site may be a JavaScript-rendered SPA, or the pages may not contain structured term definitions."
      )
    }
  }, [url, maxDepth, maxPages])

  const stopCrawl = useCallback(() => {
    abortRef.current = true
  }, [])

  const handleImport = useCallback(() => {
    if (crawlState.allTerms.length === 0) return
    const selectedTerms = crawlState.allTerms.filter((t) => selectedTermIds.has(t.id))
    if (selectedTerms.length === 0) return
    onImport(selectedTerms, crawlState.rootTitle, url)
  }, [crawlState, selectedTermIds, onImport, url])

  // ── Selection helpers ──
  const toggleTerm = (termId: string) => {
    setSelectedTermIds((prev) => {
      const next = new Set(prev)
      if (next.has(termId)) next.delete(termId)
      else next.add(termId)
      return next
    })
  }

  const toggleAll = () => {
    if (selectedTermIds.size === crawlState.allTerms.length) {
      setSelectedTermIds(new Set())
    } else {
      setSelectedTermIds(new Set(crawlState.allTerms.map((t) => t.id)))
    }
  }

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev)
      if (next.has(section)) next.delete(section)
      else next.add(section)
      return next
    })
  }

  const toggleSectionTerms = (sectionTerms: ParsedTerm[]) => {
    const allSelected = sectionTerms.every((t) => selectedTermIds.has(t.id))
    setSelectedTermIds((prev) => {
      const next = new Set(prev)
      sectionTerms.forEach((t) => {
        if (allSelected) next.delete(t.id)
        else next.add(t.id)
      })
      return next
    })
  }

  // ── Group / filter ──
  const groupedTerms = crawlState.allTerms.reduce<Record<string, ParsedTerm[]>>((acc, term) => {
    const section = term.section || "Uncategorized"
    if (!acc[section]) acc[section] = []
    acc[section].push(term)
    return acc
  }, {})

  const filteredGroups = Object.entries(groupedTerms).reduce<Record<string, ParsedTerm[]>>(
    (acc, [section, terms]) => {
      if (!filterQuery.trim()) {
        acc[section] = terms
        return acc
      }
      const q = filterQuery.toLowerCase()
      const filtered = terms.filter(
        (t) =>
          t.label.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.uri.toLowerCase().includes(q)
      )
      if (filtered.length > 0) acc[section] = filtered
      return acc
    },
    {}
  )

  const isBusy = crawlState.status === "discovering" || crawlState.status === "parsing"
  const isDone = crawlState.status === "done" || crawlState.status === "stopped"
  const progress =
    crawlState.totalDiscovered > 0
      ? Math.round((crawlState.totalParsed / crawlState.totalDiscovered) * 100)
      : 0

  return (
    <div className="flex flex-col gap-6">
      {/* URL Input */}
      <div className="flex flex-col gap-2">
        <Label htmlFor="ontology-url" className="text-sm font-medium text-foreground">
          Ontology Website URL
        </Label>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Globe className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="ontology-url"
              placeholder="https://federatief.datastelsel.nl/kennisbank/"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !isBusy) startCrawl()
              }}
              className="bg-secondary/50 border-border pl-10 text-foreground placeholder:text-muted-foreground"
              disabled={isBusy}
            />
          </div>
          {isBusy ? (
            <Button onClick={stopCrawl} variant="destructive">
              <StopCircle className="mr-2 h-4 w-4" />
              Stop
            </Button>
          ) : (
            <Button onClick={startCrawl} disabled={!url.trim()} variant="secondary">
              <Layers className="mr-2 h-4 w-4" />
              Crawl & Parse
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Enters the URL, follows all same-domain links (navigation, sidebar, content),
          and recursively parses each page for ontology terms and definitions.
        </p>
      </div>

      {/* Crawl Settings */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Label htmlFor="max-depth" className="text-xs text-muted-foreground whitespace-nowrap">
            Max depth
          </Label>
          <Input
            id="max-depth"
            type="number"
            min={1}
            max={10}
            value={maxDepth}
            onChange={(e) => setMaxDepth(Number(e.target.value))}
            className="bg-secondary/50 border-border text-foreground w-16 h-8 text-xs"
            disabled={isBusy}
          />
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="max-pages" className="text-xs text-muted-foreground whitespace-nowrap">
            Max pages
          </Label>
          <Input
            id="max-pages"
            type="number"
            min={1}
            max={200}
            value={maxPages}
            onChange={(e) => setMaxPages(Number(e.target.value))}
            className="bg-secondary/50 border-border text-foreground w-20 h-8 text-xs"
            disabled={isBusy}
          />
        </div>
      </div>

      {/* Crawl Progress */}
      {(isBusy || isDone) && (
        <div className="flex flex-col gap-3 rounded-lg border border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isBusy ? (
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
              ) : crawlState.status === "stopped" ? (
                <StopCircle className="h-4 w-4 text-warning" />
              ) : (
                <CheckCircle2 className="h-4 w-4 text-success" />
              )}
              <span className="text-sm font-medium text-foreground">
                {isBusy
                  ? crawlState.status === "discovering"
                    ? "Discovering pages..."
                    : "Parsing pages..."
                  : crawlState.status === "stopped"
                    ? "Crawl stopped"
                    : "Crawl complete"}
              </span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>{crawlState.totalParsed} / {crawlState.totalDiscovered} pages</span>
              <span>{crawlState.allTerms.length} terms found</span>
            </div>
          </div>

          <Progress value={progress} className="h-1.5" />

          {/* Page List Toggle */}
          <button
            onClick={() => setShowPages((p) => !p)}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors self-start"
          >
            {showPages ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            {showPages ? "Hide" : "Show"} crawled pages ({crawlState.pages.length})
          </button>

          {showPages && (
            <ScrollArea className="max-h-48 rounded border border-border/50">
              <div className="flex flex-col">
                {crawlState.pages.map((page, i) => (
                  <div
                    key={`${page.url}-${i}`}
                    className="flex items-center gap-2 px-3 py-1.5 text-xs border-b border-border/30 last:border-b-0"
                  >
                    {page.status === "crawling" || page.status === "parsing" ? (
                      <Loader2 className="h-3 w-3 animate-spin text-primary shrink-0" />
                    ) : page.status === "done" ? (
                      <CheckCircle2 className="h-3 w-3 text-success shrink-0" />
                    ) : page.status === "error" ? (
                      <AlertCircle className="h-3 w-3 text-destructive shrink-0" />
                    ) : (
                      <div className="h-3 w-3 rounded-full border border-muted-foreground/30 shrink-0" />
                    )}
                    <span className="text-foreground truncate flex-1" title={page.url}>
                      {page.label}
                    </span>
                    <Badge variant="outline" className="text-xs shrink-0">
                      {page.context}
                    </Badge>
                    {page.status === "done" && (
                      <span className="text-muted-foreground shrink-0">{page.termCount} terms</span>
                    )}
                    {page.error && (
                      <span className="text-destructive shrink-0">{page.error}</span>
                    )}
                    <a
                      href={page.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-foreground shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-start gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-destructive" />
          <div className="flex flex-col gap-1">
            <p className="text-sm font-medium text-destructive">No terms found</p>
            <p className="text-xs text-destructive/80">{error}</p>
          </div>
        </div>
      )}

      {/* Results Preview */}
      {isDone && crawlState.allTerms.length > 0 && (
        <div className="flex flex-col gap-4">
          {/* Summary */}
          <div className="flex items-start gap-3 rounded-lg border border-success/30 bg-success/5 p-4">
            <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-success" />
            <div className="flex flex-col gap-1 flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">
                {crawlState.rootTitle || "Crawled Site"}
              </p>
              <p className="text-xs text-muted-foreground">
                Crawled {crawlState.totalParsed} page{crawlState.totalParsed !== 1 ? "s" : ""},{" "}
                found {crawlState.allTerms.length} unique term{crawlState.allTerms.length !== 1 ? "s" : ""}{" "}
                across {Object.keys(groupedTerms).length} section{Object.keys(groupedTerms).length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>

          {/* Filter + Select Controls */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Filter extracted terms..."
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  className="bg-secondary/50 border-border pl-9 text-sm text-foreground placeholder:text-muted-foreground h-9"
                />
              </div>
              <Button variant="ghost" size="sm" onClick={toggleAll} className="text-xs shrink-0">
                {selectedTermIds.size === crawlState.allTerms.length ? "Deselect All" : "Select All"}
              </Button>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Badge variant="secondary" className="text-xs">
                {selectedTermIds.size} / {crawlState.allTerms.length} selected
              </Badge>
            </div>
          </div>

          {/* Term List */}
          <ScrollArea className="h-80 rounded-lg border border-border">
            <div className="flex flex-col">
              {Object.entries(filteredGroups).map(([section, terms]) => {
                const isExpanded = expandedSections.has(section)
                const allSectionSelected = terms.every((t) => selectedTermIds.has(t.id))
                const someSectionSelected = terms.some((t) => selectedTermIds.has(t.id))
                return (
                  <div key={section} className="border-b border-border last:border-b-0">
                    {/* Section Header */}
                    <div className="flex items-center gap-2 px-3 py-2 bg-secondary/30 sticky top-0 z-10">
                      <button
                        onClick={() => toggleSection(section)}
                        className="flex items-center gap-1 text-xs font-medium text-foreground hover:text-primary transition-colors"
                      >
                        {isExpanded ? (
                          <ChevronDown className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronRight className="h-3.5 w-3.5" />
                        )}
                        {section}
                      </button>
                      <Badge variant="outline" className="text-xs ml-auto">
                        {terms.length}
                      </Badge>
                      <Checkbox
                        checked={allSectionSelected}
                        onCheckedChange={() => toggleSectionTerms(terms)}
                        className="h-3.5 w-3.5"
                        aria-label={`Select all in ${section}`}
                        {...(someSectionSelected && !allSectionSelected
                          ? { "data-state": "indeterminate" }
                          : {})}
                      />
                    </div>

                    {/* Terms */}
                    {isExpanded && (
                      <div className="flex flex-col">
                        {terms.map((term) => (
                          <label
                            key={term.id}
                            className="flex items-start gap-3 px-4 py-2.5 hover:bg-secondary/20 cursor-pointer transition-colors border-t border-border/50 first:border-t-0"
                          >
                            <Checkbox
                              checked={selectedTermIds.has(term.id)}
                              onCheckedChange={() => toggleTerm(term.id)}
                              className="mt-0.5 h-3.5 w-3.5 shrink-0"
                            />
                            <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-foreground truncate">
                                  {term.label}
                                </span>
                                <Badge variant="outline" className="text-xs shrink-0">
                                  {term.type}
                                </Badge>
                              </div>
                              {term.description && (
                                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
                                  {term.description}
                                </p>
                              )}
                              {term.metadata && Object.keys(term.metadata).length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-0.5">
                                  {Object.entries(term.metadata)
                                    .slice(0, 3)
                                    .map(([key, value]) => (
                                      <span key={key} className="text-xs text-muted-foreground/70">
                                        {key}:{" "}
                                        <span className="font-mono">
                                          {value.slice(0, 40)}
                                          {value.length > 40 ? "..." : ""}
                                        </span>
                                      </span>
                                    ))}
                                </div>
                              )}
                              <span className="text-xs font-mono text-muted-foreground/60 truncate">
                                {term.uri}
                              </span>
                            </div>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
              {Object.keys(filteredGroups).length === 0 && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <p className="text-sm text-muted-foreground">No terms match your filter</p>
                </div>
              )}
            </div>
          </ScrollArea>

          {/* Import Button */}
          <Button
            onClick={handleImport}
            disabled={isProcessing || selectedTermIds.size === 0}
            className="w-full"
            size="lg"
          >
            <Download className="mr-2 h-4 w-4" />
            {isProcessing
              ? "Importing..."
              : `Import ${selectedTermIds.size} Term${selectedTermIds.size !== 1 ? "s" : ""} as Ontology`}
          </Button>
        </div>
      )}
    </div>
  )
}

// Helper to get term count from parse result (keeps the term count from the API)
function pageData_termCount(data: ParseResult): number {
  return data.termCount || data.terms.length
}
