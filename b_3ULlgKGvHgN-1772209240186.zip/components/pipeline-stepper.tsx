"use client"

import { cn } from "@/lib/utils"
import {
  Globe,
  Code2,
  BrainCircuit,
  ShieldCheck,
  Cpu,
  FileOutput,
  BadgeCheck,
  CheckCircle2,
  Loader2,
  type LucideIcon,
} from "lucide-react"

export type PipelineStage = {
  id: number
  label: string
  description: string
  icon: LucideIcon
}

export const PIPELINE_STAGES: PipelineStage[] = [
  {
    id: 1,
    label: "Fetch HTML",
    description: "Download and clean target page DOM",
    icon: Globe,
  },
  {
    id: 2,
    label: "Syntactic Parsing",
    description: "Extract candidate term/definition pairs",
    icon: Code2,
  },
  {
    id: 3,
    label: "Semantic Labeling",
    description: "Classify and type semantic roles",
    icon: BrainCircuit,
  },
  {
    id: 4,
    label: "External Validation",
    description: "Validate against knowledge graphs",
    icon: ShieldCheck,
  },
  {
    id: 5,
    label: "Semantic Extraction",
    description: "Generate high-quality triples via ML",
    icon: Cpu,
  },
  {
    id: 6,
    label: "Normalization",
    description: "Convert to RDF/OWL/JSON-LD output",
    icon: FileOutput,
  },
  {
    id: 7,
    label: "Quality Checks",
    description: "Linguistic and semantic QA validation",
    icon: BadgeCheck,
  },
]

type PipelineStepperProps = {
  currentStage: number
  status: "idle" | "running" | "complete" | "error"
}

export function PipelineStepper({ currentStage, status }: PipelineStepperProps) {
  return (
    <div className="flex flex-col gap-1">
      <h3 className="text-sm font-semibold text-foreground mb-3 tracking-wide uppercase">
        Processing Pipeline
      </h3>
      <div className="flex flex-col gap-0.5">
        {PIPELINE_STAGES.map((stage, index) => {
          const isComplete = status === "complete" || (status === "running" && stage.id < currentStage)
          const isActive = status === "running" && stage.id === currentStage
          const isPending = status === "idle" || (status === "running" && stage.id > currentStage)
          const isError = status === "error" && stage.id === currentStage
          const Icon = stage.icon

          return (
            <div key={stage.id} className="flex items-stretch gap-3">
              {/* Connector line + circle */}
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-300",
                    isComplete && "border-success bg-success/15",
                    isActive && "border-primary bg-primary/15",
                    isError && "border-destructive bg-destructive/15",
                    isPending && "border-border bg-secondary"
                  )}
                >
                  {isComplete ? (
                    <CheckCircle2 className="h-4 w-4 text-success" />
                  ) : isActive ? (
                    <Loader2 className="h-4 w-4 text-primary animate-spin" />
                  ) : isError ? (
                    <Icon className="h-4 w-4 text-destructive" />
                  ) : (
                    <Icon className={cn("h-4 w-4", isPending ? "text-muted-foreground" : "text-foreground")} />
                  )}
                </div>
                {index < PIPELINE_STAGES.length - 1 && (
                  <div
                    className={cn(
                      "w-0.5 flex-1 min-h-4 transition-colors duration-300",
                      isComplete ? "bg-success/40" : "bg-border"
                    )}
                  />
                )}
              </div>

              {/* Label + Description */}
              <div className="flex flex-col pb-4">
                <span
                  className={cn(
                    "text-sm font-medium leading-8 transition-colors duration-300",
                    isComplete && "text-success",
                    isActive && "text-primary",
                    isError && "text-destructive",
                    isPending && "text-muted-foreground"
                  )}
                >
                  {stage.label}
                </span>
                <span className="text-xs text-muted-foreground leading-relaxed">
                  {stage.description}
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
