"use client"

import { useState, useCallback, useRef } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Upload, FileUp, X, FileText } from "lucide-react"

const ACCEPTED_FORMATS = [
  { ext: ".owl", label: "OWL" },
  { ext: ".rdf", label: "RDF/XML" },
  { ext: ".ttl", label: "Turtle" },
  { ext: ".jsonld", label: "JSON-LD" },
  { ext: ".n3", label: "N3" },
  { ext: ".nt", label: "N-Triples" },
]

const ACCEPTED_EXTENSIONS = ACCEPTED_FORMATS.map((f) => f.ext)

type UploadedFile = {
  name: string
  size: number
  type: string
}

type FileUploadProps = {
  onSubmit: (files: UploadedFile[], sourceUrl: string, namespace: string) => void
  isProcessing: boolean
}

export function FileUpload({ onSubmit, isProcessing }: FileUploadProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [sourceUrl, setSourceUrl] = useState("")
  const [namespace, setNamespace] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleFiles = useCallback((fileList: FileList | null) => {
    if (!fileList) return
    const newFiles: UploadedFile[] = []
    for (let i = 0; i < fileList.length; i++) {
      const f = fileList[i]
      const ext = "." + f.name.split(".").pop()?.toLowerCase()
      if (ACCEPTED_EXTENSIONS.includes(ext)) {
        newFiles.push({ name: f.name, size: f.size, type: ext })
      }
    }
    setFiles((prev) => [...prev, ...newFiles])
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      handleFiles(e.dataTransfer.files)
    },
    [handleFiles]
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const handleSubmit = () => {
    if (files.length === 0 && !sourceUrl) return
    onSubmit(files, sourceUrl, namespace)
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Drop Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed p-8 transition-colors cursor-pointer",
          isDragging
            ? "border-primary bg-primary/5"
            : "border-border hover:border-muted-foreground/40 hover:bg-secondary/50"
        )}
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary">
          <Upload className="h-5 w-5 text-muted-foreground" />
        </div>
        <div className="text-center">
          <p className="text-sm font-medium text-foreground">
            Drop ontology files here or click to browse
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Supported: OWL, RDF/XML, Turtle, JSON-LD, N3, N-Triples
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-1.5">
          {ACCEPTED_FORMATS.map((fmt) => (
            <Badge key={fmt.ext} variant="secondary" className="text-xs">
              {fmt.label}
            </Badge>
          ))}
        </div>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPTED_EXTENSIONS.join(",")}
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
        />
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="flex flex-col gap-2">
          <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Queued Files ({files.length})
          </Label>
          <div className="flex flex-col gap-1.5">
            {files.map((file, index) => (
              <div
                key={`${file.name}-${index}`}
                className="flex items-center gap-3 rounded-md bg-secondary/50 px-3 py-2 border border-border"
              >
                <FileText className="h-4 w-4 shrink-0 text-primary" />
                <div className="flex flex-1 flex-col min-w-0">
                  <span className="text-sm font-medium text-foreground truncate">
                    {file.name}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatSize(file.size)}
                  </span>
                </div>
                <Badge variant="outline" className="text-xs shrink-0">
                  {file.type}
                </Badge>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeFile(index)
                  }}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                  aria-label={`Remove ${file.name}`}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Metadata Fields */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="source-url" className="text-sm font-medium text-foreground">
            Source URL
            <span className="ml-1 text-muted-foreground font-normal">(optional)</span>
          </Label>
          <Input
            id="source-url"
            placeholder="https://example.org/ontology"
            value={sourceUrl}
            onChange={(e) => setSourceUrl(e.target.value)}
            className="bg-secondary/50 border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label htmlFor="namespace" className="text-sm font-medium text-foreground">
            Target Namespace
            <span className="ml-1 text-muted-foreground font-normal">(optional)</span>
          </Label>
          <Input
            id="namespace"
            placeholder="http://example.org/ontology#"
            value={namespace}
            onChange={(e) => setNamespace(e.target.value)}
            className="bg-secondary/50 border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Submit */}
      <Button
        onClick={handleSubmit}
        disabled={isProcessing || (files.length === 0 && !sourceUrl)}
        className="w-full"
        size="lg"
      >
        <FileUp className="mr-2 h-4 w-4" />
        {isProcessing ? "Processing..." : "Upload & Process Ontology"}
      </Button>
    </div>
  )
}
