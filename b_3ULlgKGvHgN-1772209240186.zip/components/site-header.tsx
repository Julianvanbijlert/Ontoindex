"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Layers, Upload, Search, BookOpen } from "lucide-react"

const NAV_ITEMS = [
  { href: "/", label: "Upload", icon: Upload },
  { href: "/search", label: "Search", icon: Search },
  { href: "/definitions", label: "Definitions", icon: BookOpen },
]

export function SiteHeader() {
  const pathname = usePathname()

  return (
    <header className="border-b border-border bg-card/50">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 border border-primary/25">
              <Layers className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground tracking-tight">
                Ontology Platform
              </h1>
              <p className="text-xs text-muted-foreground">
                Federated discovery, indexing & semantic intelligence
              </p>
            </div>
          </div>

          <nav className="hidden items-center gap-1 sm:flex" aria-label="Main navigation">
            {NAV_ITEMS.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  {item.label}
                </Link>
              )
            })}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1.5 text-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
            System Online
          </Badge>
        </div>
      </div>
    </header>
  )
}
