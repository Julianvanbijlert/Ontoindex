"use client"

import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertTriangle, Clock, FileJson } from "lucide-react"

export type ProcessingResult = {
  status: "success" | "error" | "warning"
  message: string
  details: string[]
  outputFormat?: string
  tripleCount?: number
  duration?: number
} | null

type ResultPanelProps = {
  result: ProcessingResult
}

export function ResultPanel({ result }: ResultPanelProps) {
  if (!result) return null

  return (
    <div className="flex flex-col gap-3 rounded-lg border border-border bg-secondary/30 p-4">
      <div className="flex items-center gap-2">
        {result.status === "success" ? (
          <CheckCircle2 className="h-5 w-5 text-success" />
        ) : result.status === "error" ? (
          <AlertTriangle className="h-5 w-5 text-destructive" />
        ) : (
          <AlertTriangle className="h-5 w-5 text-warning" />
        )}
        <span className="text-sm font-semibold text-foreground">
          {result.message}
        </span>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-2">
        {result.tripleCount !== undefined && (
          <Badge variant="secondary" className="gap-1">
            <FileJson className="h-3 w-3" />
            {result.tripleCount} triples
          </Badge>
        )}
        {result.outputFormat && (
          <Badge variant="secondary" className="gap-1">
            {result.outputFormat}
          </Badge>
        )}
        {result.duration !== undefined && (
          <Badge variant="secondary" className="gap-1">
            <Clock className="h-3 w-3" />
            {result.duration}ms
          </Badge>
        )}
      </div>

      {/* Details */}
      {result.details.length > 0 && (
        <div className="flex flex-col gap-1.5 rounded-md bg-background/50 p-3 border border-border">
          {result.details.map((detail, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
              <span className="text-xs text-muted-foreground leading-relaxed font-mono">
                {detail}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
