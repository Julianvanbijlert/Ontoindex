"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, Copy, Check } from "lucide-react"

const EXAMPLE_QUERIES = [
  {
    label: "List all classes",
    query: `PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?class ?label ?comment
WHERE {
  ?class a owl:Class .
  OPTIONAL { ?class rdfs:label ?label }
  OPTIONAL { ?class rdfs:comment ?comment }
}
ORDER BY ?label`,
  },
  {
    label: "Find properties",
    query: `PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?property ?domain ?range
WHERE {
  ?property a owl:ObjectProperty .
  OPTIONAL { ?property rdfs:domain ?domain }
  OPTIONAL { ?property rdfs:range ?range }
}`,
  },
  {
    label: "Class hierarchy",
    query: `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>

SELECT ?child ?parent
WHERE {
  ?child rdfs:subClassOf ?parent .
  ?child a owl:Class .
  ?parent a owl:Class .
}
ORDER BY ?parent ?child`,
  },
  {
    label: "Insert ontology class",
    query: `PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX ex: <http://example.org/ontology#>

INSERT DATA {
  ex:NewConcept a owl:Class ;
    rdfs:label "New Concept"@en ;
    rdfs:comment "A newly defined concept"@en ;
    rdfs:subClassOf owl:Thing .
}`,
  },
]

type QueryEditorProps = {
  onSubmit: (query: string, endpoint: string) => void
  isProcessing: boolean
}

export function QueryEditor({ onSubmit, isProcessing }: QueryEditorProps) {
  const [query, setQuery] = useState(EXAMPLE_QUERIES[0].query)
  const [endpoint, setEndpoint] = useState("http://localhost:3030/ontology/sparql")
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    await navigator.clipboard.writeText(query)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSubmit = () => {
    if (!query.trim()) return
    onSubmit(query, endpoint)
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Endpoint */}
      <div className="flex flex-col gap-2">
        <Label htmlFor="endpoint" className="text-sm font-medium text-foreground">
          SPARQL Endpoint
        </Label>
        <Input
          id="endpoint"
          value={endpoint}
          onChange={(e) => setEndpoint(e.target.value)}
          placeholder="http://localhost:3030/ontology/sparql"
          className="bg-secondary/50 border-border text-foreground font-mono text-sm placeholder:text-muted-foreground"
        />
      </div>

      {/* Example Queries */}
      <div className="flex flex-col gap-2">
        <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Templates
        </Label>
        <div className="flex flex-wrap gap-1.5">
          {EXAMPLE_QUERIES.map((ex) => (
            <Badge
              key={ex.label}
              variant="outline"
              className="cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-colors text-xs"
              onClick={() => setQuery(ex.query)}
            >
              {ex.label}
            </Badge>
          ))}
        </div>
      </div>

      {/* Query Editor */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="query" className="text-sm font-medium text-foreground">
            SPARQL Query
          </Label>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Copy query"
          >
            {copied ? (
              <>
                <Check className="h-3 w-3" />
                Copied
              </>
            ) : (
              <>
                <Copy className="h-3 w-3" />
                Copy
              </>
            )}
          </button>
        </div>
        <div className="relative">
          <textarea
            id="query"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={14}
            spellCheck={false}
            className="w-full resize-none rounded-lg border border-border bg-secondary/30 p-4 font-mono text-sm text-foreground leading-relaxed placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 focus:border-primary/50"
            placeholder="Enter your SPARQL query..."
          />
          {/* Line count indicator */}
          <div className="absolute bottom-3 right-3 text-xs text-muted-foreground">
            {query.split("\n").length} lines
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <Button
          onClick={handleSubmit}
          disabled={isProcessing || !query.trim()}
          className="flex-1"
          size="lg"
        >
          <Play className="mr-2 h-4 w-4" />
          {isProcessing ? "Executing..." : "Execute Query"}
        </Button>
        <Button
          variant="outline"
          size="lg"
          onClick={() => setQuery("")}
          disabled={isProcessing}
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Clear
        </Button>
      </div>
    </div>
  )
}
