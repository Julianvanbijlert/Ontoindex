import { useSyncExternalStore, useCallback } from "react"

export type OntologyStatus = "processed" | "pending" | "error"

export type OntologyTriple = {
  subject: string
  predicate: string
  object: string
}

export type OntologyClass = {
  uri: string
  label: string
  description: string
  parentClass: string
}

export type OntologyProperty = {
  uri: string
  label: string
  type: "object" | "data"
  domain: string
  range: string
}

export type OntologyEntry = {
  id: string
  name: string
  format: string
  size: number
  sourceUrl: string
  namespace: string
  status: OntologyStatus
  uploadedAt: Date
  tripleCount: number
  classCount: number
  propertyCount: number
  domain: string
  description: string
  classes: OntologyClass[]
  properties: OntologyProperty[]
  triples: OntologyTriple[]
}

// Helper to generate simulated ontology contents based on file name
export function generateOntologyContents(fileName: string, namespace: string) {
  const baseName = fileName.replace(/\.[^.]+$/, "")
  const ns = namespace || `http://example.org/${baseName}#`

  const classes: OntologyClass[] = [
    { uri: `${ns}Entity`, label: "Entity", description: `Top-level entity class in ${baseName}`, parentClass: "owl:Thing" },
    { uri: `${ns}Agent`, label: "Agent", description: "An active entity that can perform actions", parentClass: `${ns}Entity` },
    { uri: `${ns}Organization`, label: "Organization", description: "A structured group of agents", parentClass: `${ns}Agent` },
    { uri: `${ns}Person`, label: "Person", description: "A human individual", parentClass: `${ns}Agent` },
    { uri: `${ns}Document`, label: "Document", description: "A written or digital record", parentClass: `${ns}Entity` },
    { uri: `${ns}Policy`, label: "Policy", description: "A set of rules or guidelines", parentClass: `${ns}Document` },
    { uri: `${ns}Regulation`, label: "Regulation", description: "An official rule governing conduct", parentClass: `${ns}Policy` },
    { uri: `${ns}Event`, label: "Event", description: "A temporal occurrence or happening", parentClass: `${ns}Entity` },
    { uri: `${ns}Location`, label: "Location", description: "A geographic or abstract place", parentClass: `${ns}Entity` },
    { uri: `${ns}Concept`, label: "Concept", description: "An abstract idea or notion", parentClass: `${ns}Entity` },
    { uri: `${ns}Activity`, label: "Activity", description: "An action or process carried out by an agent", parentClass: `${ns}Event` },
    { uri: `${ns}Artifact`, label: "Artifact", description: "A physical or digital object created by an agent", parentClass: `${ns}Entity` },
    { uri: `${ns}Role`, label: "Role", description: "A function assumed by an agent", parentClass: `${ns}Concept` },
    { uri: `${ns}Relationship`, label: "Relationship", description: "A connection between two entities", parentClass: `${ns}Concept` },
    { uri: `${ns}Category`, label: "Category", description: "A classification grouping for entities", parentClass: `${ns}Concept` },
  ]

  const properties: OntologyProperty[] = [
    { uri: `${ns}hasName`, label: "hasName", type: "data", domain: `${ns}Entity`, range: "xsd:string" },
    { uri: `${ns}hasDescription`, label: "hasDescription", type: "data", domain: `${ns}Entity`, range: "xsd:string" },
    { uri: `${ns}createdDate`, label: "createdDate", type: "data", domain: `${ns}Entity`, range: "xsd:dateTime" },
    { uri: `${ns}modifiedDate`, label: "modifiedDate", type: "data", domain: `${ns}Entity`, range: "xsd:dateTime" },
    { uri: `${ns}hasMember`, label: "hasMember", type: "object", domain: `${ns}Organization`, range: `${ns}Person` },
    { uri: `${ns}belongsTo`, label: "belongsTo", type: "object", domain: `${ns}Person`, range: `${ns}Organization` },
    { uri: `${ns}authored`, label: "authored", type: "object", domain: `${ns}Agent`, range: `${ns}Document` },
    { uri: `${ns}governs`, label: "governs", type: "object", domain: `${ns}Policy`, range: `${ns}Activity` },
    { uri: `${ns}locatedIn`, label: "locatedIn", type: "object", domain: `${ns}Entity`, range: `${ns}Location` },
    { uri: `${ns}hasRole`, label: "hasRole", type: "object", domain: `${ns}Agent`, range: `${ns}Role` },
    { uri: `${ns}relatedTo`, label: "relatedTo", type: "object", domain: `${ns}Entity`, range: `${ns}Entity` },
    { uri: `${ns}categorizedAs`, label: "categorizedAs", type: "object", domain: `${ns}Entity`, range: `${ns}Category` },
    { uri: `${ns}startDate`, label: "startDate", type: "data", domain: `${ns}Event`, range: "xsd:dateTime" },
    { uri: `${ns}endDate`, label: "endDate", type: "data", domain: `${ns}Event`, range: "xsd:dateTime" },
    { uri: `${ns}identifier`, label: "identifier", type: "data", domain: `${ns}Entity`, range: "xsd:string" },
    { uri: `${ns}status`, label: "status", type: "data", domain: `${ns}Entity`, range: "xsd:string" },
    { uri: `${ns}partOf`, label: "partOf", type: "object", domain: `${ns}Entity`, range: `${ns}Entity` },
    { uri: `${ns}producedBy`, label: "producedBy", type: "object", domain: `${ns}Artifact`, range: `${ns}Agent` },
  ]

  const triples: OntologyTriple[] = [
    ...classes.map((c) => ({ subject: c.uri, predicate: "rdf:type", object: "owl:Class" })),
    ...classes.filter((c) => c.parentClass).map((c) => ({ subject: c.uri, predicate: "rdfs:subClassOf", object: c.parentClass })),
    ...classes.map((c) => ({ subject: c.uri, predicate: "rdfs:label", object: `"${c.label}"` })),
    ...classes.map((c) => ({ subject: c.uri, predicate: "rdfs:comment", object: `"${c.description}"` })),
    ...properties.map((p) => ({ subject: p.uri, predicate: "rdf:type", object: p.type === "object" ? "owl:ObjectProperty" : "owl:DatatypeProperty" })),
    ...properties.map((p) => ({ subject: p.uri, predicate: "rdfs:domain", object: p.domain })),
    ...properties.map((p) => ({ subject: p.uri, predicate: "rdfs:range", object: p.range })),
    ...properties.map((p) => ({ subject: p.uri, predicate: "rdfs:label", object: `"${p.label}"` })),
    { subject: ns, predicate: "rdf:type", object: "owl:Ontology" },
    { subject: ns, predicate: "rdfs:label", object: `"${baseName} Ontology"` },
    { subject: ns, predicate: "owl:versionInfo", object: '"1.0.0"' },
  ]

  return {
    classes,
    properties,
    triples,
    classCount: classes.length,
    propertyCount: properties.length,
    tripleCount: triples.length,
  }
}

const STORAGE_KEY = "ontology-store"

function loadFromStorage(): OntologyEntry[] {
  if (typeof window === "undefined") return []
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    // Rehydrate Date objects
    return parsed.map((o: OntologyEntry) => ({
      ...o,
      uploadedAt: new Date(o.uploadedAt),
    }))
  } catch {
    return []
  }
}

function saveToStorage(entries: OntologyEntry[]) {
  if (typeof window === "undefined") return
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(entries))
  } catch {
    // ignore quota errors
  }
}

// Module-level store — starts empty, hydrated from sessionStorage on first access
let ontologies: OntologyEntry[] = loadFromStorage()
const listeners = new Set<() => void>()

function emitChange() {
  saveToStorage(ontologies)
  listeners.forEach((listener) => listener())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function getSnapshot(): OntologyEntry[] {
  return ontologies
}

const EMPTY_ARRAY: OntologyEntry[] = []

function getServerSnapshot(): OntologyEntry[] {
  return EMPTY_ARRAY
}

export function addOntology(entry: OntologyEntry) {
  ontologies = [entry, ...ontologies]
  emitChange()
}

export function removeOntology(id: string) {
  ontologies = ontologies.filter((o) => o.id !== id)
  emitChange()
}

export function useOntologyStore() {
  const data = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)

  const add = useCallback((entry: OntologyEntry) => {
    addOntology(entry)
  }, [])

  const remove = useCallback((id: string) => {
    removeOntology(id)
  }, [])

  return { ontologies: data, addOntology: add, removeOntology: remove }
}
