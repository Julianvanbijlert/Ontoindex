import { NextRequest, NextResponse } from "next/server"
import * as cheerio from "cheerio"

export type CrawlLink = {
  url: string
  label: string
  context: string // where the link was found (sidebar, nav, main content, etc.)
}

/**
 * Crawls a page and discovers same-origin links, categorizing them as
 * sidebar/nav links, content links, etc. Does NOT parse terms - that's
 * done by /api/parse-url. This endpoint focuses on link discovery.
 */
export async function POST(request: NextRequest) {
  try {
    const { url, baseDomain } = await request.json()

    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    let parsedUrl: URL
    try {
      parsedUrl = new URL(url)
    } catch {
      return NextResponse.json({ error: "Invalid URL format" }, { status: 400 })
    }

    const effectiveBaseDomain = baseDomain || parsedUrl.origin

    const fetchOpts = {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "nl,en;q=0.9",
      },
      signal: AbortSignal.timeout(15000),
    }

    let html = ""
    try {
      const response = await fetch(parsedUrl.toString(), fetchOpts)
      if (!response.ok) {
        return NextResponse.json(
          { error: `Failed to fetch: ${response.status}` },
          { status: 502 }
        )
      }
      html = await response.text()
    } catch (fetchErr) {
      return NextResponse.json(
        { error: `Network error: ${fetchErr instanceof Error ? fetchErr.message : "unknown"}` },
        { status: 502 }
      )
    }

    const $ = cheerio.load(html)
    const links: CrawlLink[] = []
    const seenUrls = new Set<string>()

    function clean(text: string): string {
      return text.replace(/\s+/g, " ").trim()
    }

    function normalizeUrl(href: string): string | null {
      try {
        const resolved = new URL(href, parsedUrl.origin)
        // Remove fragment
        resolved.hash = ""
        // Remove trailing slash for consistency
        let normalized = resolved.toString()
        if (normalized.endsWith("/") && normalized !== resolved.origin + "/") {
          normalized = normalized.slice(0, -1)
        }
        return normalized
      } catch {
        return null
      }
    }

    function isValidPageLink(href: string, resolvedUrl: string): boolean {
      // Must be same origin
      try {
        const u = new URL(resolvedUrl)
        if (!resolvedUrl.startsWith(effectiveBaseDomain)) return false
        // Skip non-page resources
        const ext = u.pathname.split(".").pop()?.toLowerCase() || ""
        if (
          ["pdf", "png", "jpg", "jpeg", "gif", "svg", "css", "js", "zip", "xml", "json", "rdf", "ttl", "owl", "woff", "woff2", "eot", "ico"].includes(ext)
        )
          return false
        // Skip mailto/tel/javascript
        if (/^(mailto:|tel:|javascript:)/.test(href)) return false
        return true
      } catch {
        return false
      }
    }

    // Skip the current page itself
    const currentNormalized = normalizeUrl(url)
    if (currentNormalized) seenUrls.add(currentNormalized)

    // ──────────────────────────────────────────────
    // 1. Sidebar / navigation links (highest priority)
    // ──────────────────────────────────────────────
    const navSelectors = [
      "nav a[href]",
      "[role=navigation] a[href]",
      ".sidebar a[href]",
      "[class*=sidebar] a[href]",
      "[class*=sidenav] a[href]",
      "[class*=side-nav] a[href]",
      "[class*=menu] a[href]",
      "[class*=nav-list] a[href]",
      "[class*=toc] a[href]",
      "#toc a[href]",
      ".table-of-contents a[href]",
      "[class*=breadcrumb] a[href]",
      "aside a[href]",
    ]

    for (const selector of navSelectors) {
      $(selector).each((_, el) => {
        const $a = $(el)
        const href = $a.attr("href") || ""
        const label = clean($a.text())
        if (!label || label.length < 2 || label.length > 120) return

        const resolved = normalizeUrl(href)
        if (!resolved || seenUrls.has(resolved)) return
        if (!isValidPageLink(href, resolved)) return

        seenUrls.add(resolved)
        links.push({ url: resolved, label, context: "navigation" })
      })
    }

    // ──────────────────────────────────────────────
    // 2. Content area links
    // ──────────────────────────────────────────────
    const contentSelectors = [
      "main a[href]",
      "article a[href]",
      "[role=main] a[href]",
      ".content a[href]",
      "[class*=content] a[href]",
    ]

    for (const selector of contentSelectors) {
      $(selector).each((_, el) => {
        const $a = $(el)
        const href = $a.attr("href") || ""
        const label = clean($a.text())
        if (!label || label.length < 2 || label.length > 120) return

        // Skip generic UI links
        if (/^(home|menu|terug|back|next|previous|volgende|vorige|skip|login|search|zoek|inloggen|uitloggen|cookie|privacy|disclaimer|contact)$/i.test(label))
          return

        const resolved = normalizeUrl(href)
        if (!resolved || seenUrls.has(resolved)) return
        if (!isValidPageLink(href, resolved)) return

        seenUrls.add(resolved)
        links.push({ url: resolved, label, context: "content" })
      })
    }

    // ──────────────────────────────────────────────
    // 3. Remaining page links (lower priority)
    // ──────────────────────────────────────────────
    $("a[href]").each((_, el) => {
      const $a = $(el)
      const href = $a.attr("href") || ""
      const label = clean($a.text())
      if (!label || label.length < 2 || label.length > 120) return

      if (/^(home|menu|terug|back|next|previous|volgende|vorige|skip|login|search|zoek|inloggen|uitloggen|cookie|privacy|disclaimer|contact|footer|header)$/i.test(label))
        return

      const resolved = normalizeUrl(href)
      if (!resolved || seenUrls.has(resolved)) return
      if (!isValidPageLink(href, resolved)) return

      // Check if it's in a footer or purely UI element
      const $parent = $a.closest("footer, [class*=footer], [class*=cookie], [class*=privacy]")
      if ($parent.length) return

      seenUrls.add(resolved)
      links.push({ url: resolved, label, context: "other" })
    })

    // Extract page title
    const pageTitle =
      $("title").text().trim() ||
      $("h1").first().text().trim() ||
      $('meta[property="og:title"]').attr("content") ||
      "Unknown"

    return NextResponse.json({
      success: true,
      url,
      pageTitle: clean(pageTitle),
      linkCount: links.length,
      links,
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error"
    return NextResponse.json({ error: `Crawl failed: ${message}` }, { status: 500 })
  }
}
