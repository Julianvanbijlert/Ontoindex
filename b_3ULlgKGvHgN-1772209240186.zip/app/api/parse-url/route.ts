import { NextRequest, NextResponse } from "next/server"
import * as cheerio from "cheerio"

export type ParsedTerm = {
  id: string
  label: string
  uri: string
  description: string
  section: string
  type: "class" | "property" | "definition" | "concept"
  sourceUrl: string
  metadata?: Record<string, string>
}

/**
 * Fetches an ontology HTML page and extracts term definitions using
 * multiple strategies tailored for Dutch government / ReSpec / ontology sites.
 */
export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()

    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    let parsedUrl: URL
    try {
      parsedUrl = new URL(url)
    } catch {
      return NextResponse.json({ error: "Invalid URL format" }, { status: 400 })
    }

    // Fetch with multiple user-agent fallbacks
    let html = ""
    const fetchOpts = {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "nl,en;q=0.9",
      },
      signal: AbortSignal.timeout(20000),
    }

    try {
      const response = await fetch(parsedUrl.toString(), fetchOpts)
      if (!response.ok) {
        return NextResponse.json(
          { error: `Failed to fetch URL: ${response.status} ${response.statusText}` },
          { status: 502 }
        )
      }
      html = await response.text()
    } catch (fetchErr) {
      return NextResponse.json(
        {
          error: `Could not reach the URL: ${fetchErr instanceof Error ? fetchErr.message : "Network error"}`,
        },
        { status: 502 }
      )
    }

    console.log("[v0] Fetched HTML length:", html.length)

    const $ = cheerio.load(html)
    const terms: ParsedTerm[] = []
    const seenKeys = new Set<string>()
    const baseUrl = parsedUrl.origin + parsedUrl.pathname

    function addTerm(term: Omit<ParsedTerm, "id">) {
      const normalizedLabel = term.label.trim().replace(/\s+/g, " ")
      if (!normalizedLabel || normalizedLabel.length < 2) return

      // Deduplicate by label+section
      const dedupeKey = `${normalizedLabel.toLowerCase()}||${term.section.toLowerCase()}`
      if (seenKeys.has(dedupeKey)) return
      seenKeys.add(dedupeKey)

      terms.push({
        ...term,
        label: normalizedLabel,
        id: `term-${terms.length}-${normalizedLabel.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40)}`,
      })
    }

    // Helper: find section name for an element
    function findSection($el: cheerio.Cheerio<cheerio.Element>): string {
      // Walk up to find the closest section/article with a heading
      const containers = ["section", "article", "div.section", "div[id]"]
      for (const sel of containers) {
        const $sec = $el.closest(sel)
        if ($sec.length) {
          const $h = $sec.children("h1, h2, h3, h4, h5, h6").first()
          if ($h.length) return $h.text().trim().replace(/^[\d.]+\s*/, "")
        }
      }
      return ""
    }

    // Helper: clean text
    function clean(text: string): string {
      return text.replace(/\s+/g, " ").trim()
    }

    // ──────────────────────────────────────────────
    // Strategy 1: ReSpec key-value tables (Dutch ontology pattern)
    // These have rows like: | URI | ... | / | Definitie | ... | / | Specialisatie van | ... |
    // Usually found after h3/h4/h5 section headings
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 1: ReSpec key-value tables")
    let s1count = 0
    $("table").each((_, table) => {
      const $table = $(table)
      const rows: { key: string; value: string; valueHtml: string }[] = []

      $table.find("tr").each((_, tr) => {
        const cells = $(tr).find("td, th")
        if (cells.length >= 2) {
          const key = clean($(cells[0]).text())
          const value = clean($(cells[1]).text())
          const valueHtml = $(cells[1]).html() || ""
          rows.push({ key, value, valueHtml })
        }
      })

      // Check if this looks like a ReSpec property table
      const keys = rows.map((r) => r.key.toLowerCase())
      const isReSpecTable =
        keys.some((k) =>
          /^(uri|iri|definitie|definition|specialisatie|subclass|eigenschap|property|datatype|gerelateerde)/.test(k)
        )

      if (!isReSpecTable) return

      // Extract data from key-value rows
      const data: Record<string, string> = {}
      for (const row of rows) {
        data[row.key.toLowerCase()] = row.value
      }

      const uri = data["uri"] || data["iri"] || ""
      const definitie =
        data["definitie"] || data["definition"] || data["beschrijving"] || data["description"] || ""

      // Get label from the preceding heading
      let label = ""
      const section = findSection($table)

      // Look for heading right before this table
      const $prev = $table.prev("h1, h2, h3, h4, h5, h6, [id]")
      if ($prev.length && $prev.is("h1, h2, h3, h4, h5, h6")) {
        label = clean($prev.text()).replace(/^[\d.]+\s*/, "")
      }

      // If no heading found, try the section heading itself
      if (!label) {
        const $sec = $table.closest("section, div[id]")
        if ($sec.length) {
          const $h = $sec.children("h1, h2, h3, h4, h5, h6").first()
          if ($h.length) label = clean($h.text()).replace(/^[\d.]+\s*/, "")
        }
      }

      // Fallback: derive label from URI
      if (!label && uri) {
        const hashPart = uri.split("#").pop() || uri.split("/").pop() || ""
        label = hashPart.replace(/([a-z])([A-Z])/g, "$1 $2")
      }

      if (!label) return

      // Determine type from context
      let type: ParsedTerm["type"] = "concept"
      const parentSection = findSection($table)
      if (/eigenschap|propert|relat/i.test(parentSection)) {
        type = "property"
      } else if (/klass|class/i.test(parentSection)) {
        type = "class"
      }

      const metadata: Record<string, string> = {}
      for (const row of rows) {
        if (row.key.toLowerCase() !== "uri" && row.key.toLowerCase() !== "definitie") {
          metadata[row.key] = row.value
        }
      }

      addTerm({
        label,
        uri: uri || `${baseUrl}#${label.replace(/\s+/g, "")}`,
        description: definitie.slice(0, 800),
        section: section || parentSection,
        type,
        sourceUrl: url,
        metadata,
      })
      s1count++
    })
    console.log("[v0] Strategy 1 found:", s1count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 2: <dfn> elements (W3C / ReSpec inline definitions)
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 2: <dfn> elements")
    let s2count = 0
    $("dfn").each((_, el) => {
      const $el = $(el)
      const label = clean($el.text())
      const id = $el.attr("id") || $el.closest("[id]").attr("id") || ""
      const uri = id ? `${baseUrl}#${id}` : baseUrl

      let description = ""
      const $parent = $el.parent()
      if ($parent.is("dt")) {
        const $dd = $parent.next("dd")
        description = clean($dd.text())
      } else if ($parent.is("p, li, td")) {
        description = clean($parent.text())
      }

      addTerm({
        label,
        uri,
        description: description.slice(0, 800),
        section: findSection($el),
        type: "definition",
        sourceUrl: url,
      })
      s2count++
    })
    console.log("[v0] Strategy 2 found:", s2count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 3: <dt>/<dd> definition lists
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 3: <dt>/<dd> pairs")
    let s3count = 0
    $("dl").each((_, dl) => {
      const $dl = $(dl)
      const section = findSection($dl)

      $dl.children("dt").each((_, dt) => {
        const $dt = $(dt)
        const label = clean($dt.text())
        const id = $dt.attr("id") || $dt.find("[id]").first().attr("id") || ""
        const uri = id ? `${baseUrl}#${id}` : baseUrl

        let description = ""
        let $next = $dt.next()
        while ($next.length && $next.is("dd")) {
          description += (description ? " " : "") + clean($next.text())
          $next = $next.next()
        }

        addTerm({
          label,
          uri,
          description: description.slice(0, 800),
          section,
          type: "definition",
          sourceUrl: url,
        })
        s3count++
      })
    })
    console.log("[v0] Strategy 3 found:", s3count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 4: Tables with column headers (naam, term, definitie, etc.)
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 4: Column-header tables")
    let s4count = 0
    $("table").each((_, table) => {
      const $table = $(table)
      const headers: string[] = []

      // Try thead first, then first row
      let $headerRow = $table.find("thead tr").first()
      if (!$headerRow.length) $headerRow = $table.find("tr").first()

      $headerRow.find("th, td").each((_, th) => {
        headers.push(clean($(th).text()).toLowerCase())
      })

      if (headers.length < 2) return

      const nameIdx = headers.findIndex((h) =>
        /^(term|naam|name|begrip|concept|class|eigenschap|property|label|element|entiteit|onderwerp|title|titel)$/i.test(
          h
        )
      )
      const descIdx = headers.findIndex((h) =>
        /^(definition|definitie|beschrijving|description|omschrijving|toelichting|uitleg|meaning)$/i.test(
          h
        )
      )
      const uriIdx = headers.findIndex((h) => /^(uri|iri|url|identifier|id|link)$/i.test(h))

      if (nameIdx === -1) return

      const section = findSection($table)
      let rowIdx = 0

      $table.find("tbody tr, tr").each((_, tr) => {
        rowIdx++
        if (rowIdx === 1 && headers.length > 0) return // skip header row
        const cells: string[] = []
        $(tr)
          .find("td, th")
          .each((_, td) => {
            cells.push(clean($(td).text()))
          })
        if (cells.length <= nameIdx) return

        const label = cells[nameIdx]
        const description = descIdx >= 0 && cells[descIdx] ? cells[descIdx] : ""
        const termUri = uriIdx >= 0 && cells[uriIdx] ? cells[uriIdx] : baseUrl

        addTerm({
          label,
          uri: termUri,
          description: description.slice(0, 800),
          section,
          type: "concept",
          sourceUrl: url,
        })
        s4count++
      })
    })
    console.log("[v0] Strategy 4 found:", s4count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 5: Sections with IDs that have heading + description
    // Common in ReSpec where each concept has its own section
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 5: Section headings with IDs")
    let s5count = 0
    $("section[id], div[id], article[id]").each((_, el) => {
      const $el = $(el)
      const id = $el.attr("id") || ""
      if (!id) return

      // Skip generic/navigation sections
      if (/^(toc|nav|footer|header|sidebar|menu|abstract|sotd|conformance)$/i.test(id)) return

      const $heading = $el.children("h1, h2, h3, h4, h5, h6").first()
      if (!$heading.length) return

      const label = clean($heading.text()).replace(/^[\d.]+\s*/, "")
      if (!label || label.length > 120 || label.length < 2) return

      // Get first paragraph as description
      const $para = $el.children("p").first()
      const description = $para.length ? clean($para.text()) : ""

      // Determine parent section
      let section = ""
      const $parentSection = $el.parent().closest("section[id], article")
      if ($parentSection.length) {
        const $ph = $parentSection.children("h1, h2, h3, h4, h5, h6").first()
        section = $ph.length ? clean($ph.text()).replace(/^[\d.]+\s*/, "") : ""
      }

      addTerm({
        label,
        uri: `${baseUrl}#${id}`,
        description: description.slice(0, 800),
        section,
        type: "concept",
        sourceUrl: url,
      })
      s5count++
    })
    console.log("[v0] Strategy 5 found:", s5count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 6: Links that look like term references
    // For index/knowledge base pages that are link collections
    // ──────────────────────────────────────────────
    console.log("[v0] Strategy 6: Term-like links")
    let s6count = 0

    // Look for link lists in navs, uls, and content areas
    $("a[href]").each((_, el) => {
      const $a = $(el)
      const href = $a.attr("href") || ""
      const label = clean($a.text())

      // Skip navigation/UI links
      if (!label || label.length < 2 || label.length > 100) return
      if (/^(home|menu|terug|back|next|previous|volgende|vorige|skip|login|search|zoek)$/i.test(label))
        return
      if (/^(#|javascript:|mailto:)/.test(href) && !href.match(/#[A-Z]/)) return

      // Only consider links that look like term references
      const $parent = $a.parent()
      const isInList = $parent.is("li") || $parent.parent().is("ul, ol")
      const isInCard = $parent.closest(".card, [class*=card], [class*=item], [class*=begrip]").length > 0
      const isInContent = $parent.closest("main, article, .content, [role=main]").length > 0

      if (!isInList && !isInCard && !isInContent) return

      // Get description from surrounding context
      let description = ""
      if ($parent.is("li")) {
        // Check if there's text after the link in the list item
        const liText = clean($parent.text())
        if (liText.length > label.length + 5) {
          description = liText.replace(label, "").trim().replace(/^[:\-–—\s]+/, "")
        }
      }
      // Check for a sibling description element
      const $desc = $parent.find(".description, .summary, .subtitle, p, .omschrijving")
      if ($desc.length && !description) {
        description = clean($desc.first().text())
      }

      // Resolve relative URLs
      let fullUri = href
      try {
        fullUri = new URL(href, parsedUrl.origin).toString()
      } catch {
        fullUri = `${baseUrl}${href}`
      }

      const section = findSection($a)

      addTerm({
        label,
        uri: fullUri,
        description: description.slice(0, 800),
        section: section || "Links",
        type: "concept",
        sourceUrl: url,
      })
      s6count++
    })
    console.log("[v0] Strategy 6 found:", s6count, "terms")

    // ──────────────────────────────────────────────
    // Strategy 7: Headings with paragraphs (fallback for content pages)
    // Only used if we found very few terms from other strategies
    // ──────────────────────────────────────────────
    if (terms.length < 3) {
      console.log("[v0] Strategy 7: Heading+paragraph fallback")
      let s7count = 0
      $("h1, h2, h3, h4, h5, h6").each((_, heading) => {
        const $h = $(heading)
        const label = clean($h.text()).replace(/^[\d.]+\s*/, "")
        if (!label || label.length < 2 || label.length > 100) return

        // Skip generic headings
        if (
          /^(inhoudsopgave|table of contents|samenvatting|abstract|inleiding|introduction|referenties|references|bijlage|appendix|colofon|conformance|status)$/i.test(
            label
          )
        )
          return

        const id = $h.attr("id") || $h.parent().attr("id") || ""

        // Get following paragraphs as description
        let description = ""
        let $next = $h.next()
        let paraCount = 0
        while ($next.length && paraCount < 2) {
          if ($next.is("p")) {
            description += (description ? " " : "") + clean($next.text())
            paraCount++
          } else if ($next.is("h1, h2, h3, h4, h5, h6")) {
            break
          }
          $next = $next.next()
        }

        const section = findSection($h)

        addTerm({
          label,
          uri: id ? `${baseUrl}#${id}` : baseUrl,
          description: description.slice(0, 800),
          section: section !== label ? section : "",
          type: "concept",
          sourceUrl: url,
        })
        s7count++
      })
      console.log("[v0] Strategy 7 found:", s7count, "terms")
    }

    console.log("[v0] Total unique terms:", terms.length)

    // Extract page title
    const pageTitle =
      $("title").text().trim() ||
      $("h1").first().text().trim() ||
      $('meta[property="og:title"]').attr("content") ||
      "Unknown"

    const pageDescription =
      $('meta[name="description"]').attr("content") ||
      $('meta[property="og:description"]').attr("content") ||
      $("p").first().text().trim().slice(0, 200) ||
      ""

    return NextResponse.json({
      success: true,
      url,
      pageTitle: clean(pageTitle),
      pageDescription: clean(pageDescription),
      termCount: terms.length,
      terms,
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error"
    console.error("[v0] Parse error:", message)
    return NextResponse.json({ error: `Failed to parse URL: ${message}` }, { status: 500 })
  }
}
