"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { PipelineStepper, PIPELINE_STAGES } from "@/components/pipeline-stepper"
import { FileUpload } from "@/components/file-upload"
import { QueryEditor } from "@/components/query-editor"
import { ResultPanel, type ProcessingResult } from "@/components/result-panel"
import { SiteHeader } from "@/components/site-header"
import { UrlImport } from "@/components/url-import"
import type { ParsedTerm } from "@/app/api/parse-url/route"
import { useOntologyStore, type OntologyEntry, generateOntologyContents } from "@/lib/ontology-store"
import { Database, Upload, Terminal, Globe } from "lucide-react"

export default function OntologyUploadPage() {
  const [currentStage, setCurrentStage] = useState(0)
  const [pipelineStatus, setPipelineStatus] = useState<"idle" | "running" | "complete" | "error">("idle")
  const [result, setResult] = useState<ProcessingResult>(null)
  const timeoutRefs = useRef<ReturnType<typeof setTimeout>[]>([])
  const { addOntology } = useOntologyStore()

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      timeoutRefs.current.forEach(clearTimeout)
    }
  }, [])

  const runPipeline = useCallback((completionResult: ProcessingResult) => {
    // Clear any existing timeouts
    timeoutRefs.current.forEach(clearTimeout)
    timeoutRefs.current = []

    setPipelineStatus("running")
    setCurrentStage(1)
    setResult(null)

    // Simulate pipeline stages with varying durations
    const stageDurations = [800, 1200, 1500, 1000, 1800, 900, 700]

    let cumulativeDelay = 0
    PIPELINE_STAGES.forEach((stage, index) => {
      cumulativeDelay += stageDurations[index]
      const timeout = setTimeout(() => {
        setCurrentStage(stage.id + 1)
      }, cumulativeDelay)
      timeoutRefs.current.push(timeout)
    })

    // Complete
    const completeTimeout = setTimeout(() => {
      setPipelineStatus("complete")
      setResult(completionResult)
    }, cumulativeDelay + 500)
    timeoutRefs.current.push(completeTimeout)
  }, [])

  const handleFileUpload = useCallback(
    (files: { name: string; size: number; type: string }[], sourceUrl: string, namespace: string) => {
      const totalSize = files.reduce((sum, f) => sum + f.size, 0)
      const resultData: ProcessingResult = {
        status: "success",
        message: "Ontology processing complete",
        details: [
          `Processed ${files.length} file(s) (${(totalSize / 1024).toFixed(1)} KB total)`,
          ...(sourceUrl ? [`Source: ${sourceUrl}`] : []),
          ...(namespace ? [`Namespace: ${namespace}`] : []),
          `Extracted 47 classes, 23 object properties, 12 data properties`,
          `Generated 342 RDF triples`,
          `SHACL validation: passed (0 violations)`,
          `Domain classification: Government & Public Policy`,
        ],
        outputFormat: "RDF/OWL",
        tripleCount: 342,
        duration: 7900,
      }

      // Add each file to the shared store
      files.forEach((file) => {
        const ns = namespace || `http://example.org/${file.name.replace(/\.[^.]+$/, "")}#`
        const contents = generateOntologyContents(file.name, ns)
        const entry: OntologyEntry = {
          id: `onto-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          name: file.name,
          format: file.type,
          size: file.size,
          sourceUrl: sourceUrl || "",
          namespace: ns,
          status: "processed",
          uploadedAt: new Date(),
          tripleCount: contents.tripleCount,
          classCount: contents.classCount,
          propertyCount: contents.propertyCount,
          domain: "Government & Public Policy",
          description: `Uploaded ontology file: ${file.name}`,
          classes: contents.classes,
          properties: contents.properties,
          triples: contents.triples,
        }
        addOntology(entry)
      })

      runPipeline(resultData)
    },
    [runPipeline, addOntology]
  )

  const handleQuerySubmit = useCallback(
    (query: string, endpoint: string) => {
      const isInsert = query.toLowerCase().includes("insert")
      const resultData: ProcessingResult = {
        status: "success",
        message: isInsert ? "Ontology data inserted successfully" : "Query executed successfully",
        details: [
          `Endpoint: ${endpoint}`,
          `Query type: ${isInsert ? "INSERT" : "SELECT"}`,
          ...(isInsert
            ? [
                `Inserted 1 new class definition`,
                `Triples added: 4`,
                `Namespace validated: true`,
              ]
            : [
                `Results returned: 24 rows`,
                `Execution time: 128ms`,
                `Graph traversals: 3`,
              ]),
        ],
        outputFormat: isInsert ? "SPARQL Update" : "SPARQL Select",
        tripleCount: isInsert ? 4 : 24,
        duration: isInsert ? 3200 : 1280,
      }
      runPipeline(resultData)
    },
    [runPipeline]
  )

  const handleUrlImport = useCallback(
    (terms: ParsedTerm[], pageTitle: string, sourceUrl: string) => {
      // Build ontology classes from the parsed terms
      const ns = sourceUrl.replace(/[#?].*$/, "") + "#"
      const classes = terms.map((t) => ({
        uri: t.uri || `${ns}${t.label.replace(/\s+/g, "")}`,
        label: t.label,
        description: t.description || "",
        parentClass: t.section ? `${ns}${t.section.replace(/\s+/g, "")}` : "owl:Thing",
      }))

      const properties: OntologyEntry["properties"] = []
      const triples = [
        ...classes.map((c) => ({ subject: c.uri, predicate: "rdf:type", object: "owl:Class" })),
        ...classes.filter((c) => c.parentClass).map((c) => ({ subject: c.uri, predicate: "rdfs:subClassOf", object: c.parentClass })),
        ...classes.map((c) => ({ subject: c.uri, predicate: "rdfs:label", object: `"${c.label}"` })),
        ...classes.filter((c) => c.description).map((c) => ({ subject: c.uri, predicate: "rdfs:comment", object: `"${c.description}"` })),
        { subject: ns, predicate: "rdf:type", object: "owl:Ontology" },
        { subject: ns, predicate: "rdfs:label", object: `"${pageTitle}"` },
      ]

      const entry: OntologyEntry = {
        id: `onto-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: pageTitle || "Imported Ontology",
        format: "text/html",
        size: terms.length * 200,
        sourceUrl,
        namespace: ns,
        status: "processed",
        uploadedAt: new Date(),
        tripleCount: triples.length,
        classCount: classes.length,
        propertyCount: 0,
        domain: "Imported from URL",
        description: `Ontology imported from ${sourceUrl} with ${terms.length} definitions`,
        classes,
        properties,
        triples,
      }
      addOntology(entry)

      const resultData: ProcessingResult = {
        status: "success",
        message: "URL import complete",
        details: [
          `Source: ${sourceUrl}`,
          `Page: ${pageTitle}`,
          `Extracted ${terms.length} definitions`,
          `Generated ${triples.length} RDF triples`,
          `Namespace: ${ns}`,
        ],
        outputFormat: "RDF/OWL (from HTML)",
        tripleCount: triples.length,
        duration: 3000,
      }

      runPipeline(resultData)
    },
    [runPipeline, addOntology]
  )

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-6 py-8">
        <div className="flex flex-col gap-6 lg:flex-row">
          {/* Left: Pipeline Stepper */}
          <aside className="w-full lg:w-72 shrink-0">
            <Card className="sticky top-8">
              <CardContent className="pt-6">
                <PipelineStepper
                  currentStage={currentStage}
                  status={pipelineStatus}
                />
              </CardContent>
            </Card>
          </aside>

          {/* Right: Upload + Query */}
          <div className="flex-1 flex flex-col gap-6 min-w-0">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" />
                  Upload Ontologies
                </CardTitle>
                <CardDescription>
                  Upload ontology files or submit SPARQL queries to ingest and process semantic definitions through the extraction pipeline.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="upload">
                  <TabsList className="mb-6">
                    <TabsTrigger value="upload" className="gap-1.5">
                      <Upload className="h-3.5 w-3.5" />
                      File Upload
                    </TabsTrigger>
                    <TabsTrigger value="query" className="gap-1.5">
                      <Terminal className="h-3.5 w-3.5" />
                      SPARQL Query
                    </TabsTrigger>
                    <TabsTrigger value="url" className="gap-1.5">
                      <Globe className="h-3.5 w-3.5" />
                      Import from URL
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="upload">
                    <FileUpload
                      onSubmit={handleFileUpload}
                      isProcessing={pipelineStatus === "running"}
                    />
                  </TabsContent>

                  <TabsContent value="query">
                    <QueryEditor
                      onSubmit={handleQuerySubmit}
                      isProcessing={pipelineStatus === "running"}
                    />
                  </TabsContent>

                  <TabsContent value="url">
                    <UrlImport
                      onImport={handleUrlImport}
                      isProcessing={pipelineStatus === "running"}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Result */}
            {result && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Processing Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResultPanel result={result} />
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
