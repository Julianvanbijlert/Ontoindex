"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { SiteHeader } from "@/components/site-header"
import {
  useOntologyStore,
  type OntologyClass,
  type OntologyProperty,
  type OntologyTriple,
} from "@/lib/ontology-store"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Search,
  Upload,
  Layers,
  GitBranch,
  ArrowRight,
  X,
  Filter,
  BookOpen,
  ExternalLink,
  Hash,
  ChevronRight,
} from "lucide-react"

type DefinitionItem = {
  kind: "class" | "property"
  label: string
  uri: string
  description: string
  ontologyId: string
  ontologyName: string
  parentClass?: string
  domain?: string
  range?: string
  propertyType?: "object" | "data"
}

export default function DefinitionsPage() {
  const { ontologies } = useOntologyStore()
  const [query, setQuery] = useState("")
  const [sourceFilter, setSourceFilter] = useState("all")
  const [kindFilter, setKindFilter] = useState<"all" | "class" | "property">("all")
  const [selectedItem, setSelectedItem] = useState<DefinitionItem | null>(null)

  // Flatten all definitions
  const allDefinitions = useMemo<DefinitionItem[]>(() => {
    const items: DefinitionItem[] = []
    ontologies.forEach((o) => {
      ;(o.classes || []).forEach((c) => {
        items.push({
          kind: "class",
          label: c.label,
          uri: c.uri,
          description: c.description,
          ontologyId: o.id,
          ontologyName: o.name,
          parentClass: c.parentClass,
        })
      })
      ;(o.properties || []).forEach((p) => {
        items.push({
          kind: "property",
          label: p.label,
          uri: p.uri,
          description: `${p.type === "object" ? "Object" : "Data"} property`,
          ontologyId: o.id,
          ontologyName: o.name,
          domain: p.domain,
          range: p.range,
          propertyType: p.type,
        })
      })
    })
    return items
  }, [ontologies])

  // Filter
  const filteredDefinitions = useMemo(() => {
    const q = query.toLowerCase().trim()
    return allDefinitions.filter((item) => {
      if (sourceFilter !== "all" && item.ontologyId !== sourceFilter) return false
      if (kindFilter !== "all" && item.kind !== kindFilter) return false
      if (!q) return true
      return [item.label, item.uri, item.description, item.parentClass || "", item.domain || "", item.range || ""]
        .join(" ")
        .toLowerCase()
        .includes(q)
    })
  }, [allDefinitions, query, sourceFilter, kindFilter])

  const hasActiveFilters = query !== "" || sourceFilter !== "all" || kindFilter !== "all"

  const clearFilters = () => {
    setQuery("")
    setSourceFilter("all")
    setKindFilter("all")
  }

  const hasOntologies = ontologies.length > 0

  // Get related triples for a definition
  function getRelatedTriples(item: DefinitionItem): OntologyTriple[] {
    const ontology = ontologies.find((o) => o.id === item.ontologyId)
    if (!ontology) return []
    return (ontology.triples || []).filter(
      (t) => t.subject === item.uri || t.object === item.uri
    )
  }

  // Get related properties for a class
  function getRelatedProperties(item: DefinitionItem): OntologyProperty[] {
    if (item.kind !== "class") return []
    const ontology = ontologies.find((o) => o.id === item.ontologyId)
    if (!ontology) return []
    return (ontology.properties || []).filter(
      (p) => p.domain === item.uri || p.range === item.uri
    )
  }

  // Get child classes
  function getChildClasses(item: DefinitionItem): OntologyClass[] {
    if (item.kind !== "class") return []
    const ontology = ontologies.find((o) => o.id === item.ontologyId)
    if (!ontology) return []
    return (ontology.classes || []).filter((c) => c.parentClass === item.uri)
  }

  function fragmentOf(uri: string) {
    if (uri.includes("#")) return uri.split("#").pop() || uri
    return uri.split("/").pop() || uri
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 py-8">
        <div className="flex flex-col gap-6">
          {/* Page Header */}
          <div>
            <h2 className="text-2xl font-semibold text-foreground tracking-tight text-balance">
              Definitions Browser
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Browse and explore all class and property definitions from your imported ontologies.
            </p>
          </div>

          {!hasOntologies ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary">
                  <Upload className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="mt-4 text-sm font-medium text-foreground">
                  No ontologies imported yet
                </p>
                <p className="mt-1 text-xs text-muted-foreground text-center max-w-sm">
                  Upload ontology files or import from a URL first, then come back here to browse their definitions.
                </p>
                <Button asChild variant="outline" size="sm" className="mt-4">
                  <Link href="/">Go to Upload</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Search + Filters */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col gap-4">
                    <div className="relative">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search definitions by label, URI, or description..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        className="bg-secondary/50 border-border pl-10 text-foreground placeholder:text-muted-foreground"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                        <Filter className="h-3.5 w-3.5" />
                        Filters
                      </div>

                      <Select value={sourceFilter} onValueChange={setSourceFilter}>
                        <SelectTrigger className="w-48 bg-secondary/50 border-border text-sm">
                          <SelectValue placeholder="All Ontologies" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Ontologies</SelectItem>
                          {ontologies.map((o) => (
                            <SelectItem key={o.id} value={o.id}>
                              {o.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={kindFilter} onValueChange={(v) => setKindFilter(v as "all" | "class" | "property")}>
                        <SelectTrigger className="w-40 bg-secondary/50 border-border text-sm">
                          <SelectValue placeholder="All Types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Types</SelectItem>
                          <SelectItem value="class">Classes</SelectItem>
                          <SelectItem value="property">Properties</SelectItem>
                        </SelectContent>
                      </Select>

                      {hasActiveFilters && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={clearFilters}
                          className="gap-1 text-xs text-muted-foreground hover:text-foreground"
                        >
                          <X className="h-3 w-3" />
                          Clear
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Stats */}
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2 rounded-md bg-secondary/50 border border-border px-3 py-1.5">
                  <BookOpen className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Definitions</span>
                  <span className="text-sm font-semibold text-foreground">{filteredDefinitions.length}</span>
                </div>
                <div className="flex items-center gap-2 rounded-md bg-secondary/50 border border-border px-3 py-1.5">
                  <Layers className="h-3.5 w-3.5 text-primary" />
                  <span className="text-xs text-muted-foreground">Classes</span>
                  <span className="text-sm font-semibold text-foreground">
                    {filteredDefinitions.filter((d) => d.kind === "class").length}
                  </span>
                </div>
                <div className="flex items-center gap-2 rounded-md bg-secondary/50 border border-border px-3 py-1.5">
                  <GitBranch className="h-3.5 w-3.5 text-chart-2" />
                  <span className="text-xs text-muted-foreground">Properties</span>
                  <span className="text-sm font-semibold text-foreground">
                    {filteredDefinitions.filter((d) => d.kind === "property").length}
                  </span>
                </div>
              </div>

              {/* Definition Cards Grid */}
              {filteredDefinitions.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Search className="h-8 w-8 text-muted-foreground/40" />
                    <p className="mt-3 text-sm font-medium text-foreground">No definitions found</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {hasActiveFilters
                        ? "Try adjusting your search or filters."
                        : "Upload ontologies to see definitions here."}
                    </p>
                    {hasActiveFilters && (
                      <Button variant="ghost" size="sm" onClick={clearFilters} className="mt-3 text-xs">
                        Clear filters
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {filteredDefinitions.map((item, idx) => (
                    <DefinitionCard
                      key={`${item.ontologyId}-${item.uri}-${idx}`}
                      item={item}
                      query={query}
                      onClick={() => setSelectedItem(item)}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Detail Sheet */}
      <Sheet open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        <SheetContent className="sm:max-w-lg overflow-y-auto">
          {selectedItem && (
            <>
              <SheetHeader>
                <div className="flex items-center gap-2">
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md border ${
                      selectedItem.kind === "class"
                        ? "bg-primary/10 border-primary/20"
                        : "bg-chart-2/10 border-chart-2/20"
                    }`}
                  >
                    {selectedItem.kind === "class" ? (
                      <Layers className="h-4 w-4 text-primary" />
                    ) : (
                      <GitBranch className="h-4 w-4 text-chart-2" />
                    )}
                  </div>
                  <div className="flex flex-col gap-0.5 min-w-0">
                    <SheetTitle className="text-left">{selectedItem.label}</SheetTitle>
                    <SheetDescription className="text-left truncate">
                      {selectedItem.kind === "class" ? "Class" : "Property"} from {selectedItem.ontologyName}
                    </SheetDescription>
                  </div>
                </div>
              </SheetHeader>

              <div className="mt-6 flex flex-col gap-5">
                {/* URI */}
                <DetailSection label="URI">
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono text-foreground/80 break-all bg-secondary/50 rounded px-2 py-1 flex-1">
                      {selectedItem.uri}
                    </code>
                    {selectedItem.uri.startsWith("http") && (
                      <a
                        href={selectedItem.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                  </div>
                </DetailSection>

                {/* Description */}
                <DetailSection label="Description">
                  <p className="text-sm text-foreground/80 leading-relaxed">{selectedItem.description}</p>
                </DetailSection>

                {/* Class-specific: Parent */}
                {selectedItem.kind === "class" && selectedItem.parentClass && (
                  <DetailSection label="Parent Class">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs font-mono gap-1">
                        <Hash className="h-3 w-3" />
                        {fragmentOf(selectedItem.parentClass)}
                      </Badge>
                      <span className="text-xs text-muted-foreground truncate font-mono">
                        {selectedItem.parentClass}
                      </span>
                    </div>
                  </DetailSection>
                )}

                {/* Property-specific: Domain & Range */}
                {selectedItem.kind === "property" && (
                  <>
                    <DetailSection label="Domain / Range">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary" className="text-xs font-mono">
                          {fragmentOf(selectedItem.domain || "")}
                        </Badge>
                        <ArrowRight className="h-3 w-3 text-muted-foreground" />
                        <Badge variant="secondary" className="text-xs font-mono">
                          {fragmentOf(selectedItem.range || "")}
                        </Badge>
                      </div>
                    </DetailSection>
                    <DetailSection label="Property Type">
                      <Badge
                        variant="outline"
                        className={
                          selectedItem.propertyType === "object"
                            ? "text-xs border-chart-2/40 text-chart-2"
                            : "text-xs border-chart-4/40 text-chart-4"
                        }
                      >
                        {selectedItem.propertyType === "object" ? "Object Property" : "Data Property"}
                      </Badge>
                    </DetailSection>
                  </>
                )}

                <Separator />

                {/* Child Classes */}
                {selectedItem.kind === "class" && (() => {
                  const children = getChildClasses(selectedItem)
                  if (children.length === 0) return null
                  return (
                    <DetailSection label={`Subclasses (${children.length})`}>
                      <div className="flex flex-wrap gap-1.5">
                        {children.map((c) => (
                          <Badge
                            key={c.uri}
                            variant="secondary"
                            className="text-xs font-mono cursor-pointer hover:bg-primary/10 hover:text-primary transition-colors"
                            onClick={() => {
                              const def = allDefinitions.find((d) => d.uri === c.uri && d.ontologyId === selectedItem.ontologyId)
                              if (def) setSelectedItem(def)
                            }}
                          >
                            <ChevronRight className="h-3 w-3 mr-0.5" />
                            {c.label}
                          </Badge>
                        ))}
                      </div>
                    </DetailSection>
                  )
                })()}

                {/* Related Properties */}
                {selectedItem.kind === "class" && (() => {
                  const relProps = getRelatedProperties(selectedItem)
                  if (relProps.length === 0) return null
                  return (
                    <DetailSection label={`Related Properties (${relProps.length})`}>
                      <div className="flex flex-col gap-1.5">
                        {relProps.map((p) => (
                          <div
                            key={p.uri}
                            className="flex items-center gap-2 text-xs cursor-pointer rounded px-2 py-1 hover:bg-secondary/50 transition-colors"
                            onClick={() => {
                              const def = allDefinitions.find((d) => d.uri === p.uri && d.ontologyId === selectedItem.ontologyId)
                              if (def) setSelectedItem(def)
                            }}
                          >
                            <GitBranch className="h-3 w-3 text-chart-2 shrink-0" />
                            <span className="font-mono text-foreground/80">{p.label}</span>
                            <span className="text-muted-foreground">
                              {p.domain === selectedItem.uri ? "(domain)" : "(range)"}
                            </span>
                          </div>
                        ))}
                      </div>
                    </DetailSection>
                  )
                })()}

                <Separator />

                {/* Related Triples */}
                {(() => {
                  const triples = getRelatedTriples(selectedItem)
                  if (triples.length === 0) return null
                  return (
                    <DetailSection label={`Related Triples (${triples.length})`}>
                      <ScrollArea className="max-h-60">
                        <div className="flex flex-col gap-1">
                          {triples.slice(0, 20).map((t, i) => (
                            <div
                              key={i}
                              className="flex items-baseline gap-1.5 text-xs font-mono bg-secondary/30 rounded px-2 py-1.5"
                            >
                              <span className="text-primary/70 shrink-0 truncate max-w-28">
                                {fragmentOf(t.subject)}
                              </span>
                              <span className="text-muted-foreground shrink-0 truncate max-w-28">
                                {fragmentOf(t.predicate)}
                              </span>
                              <span className="text-foreground/70 truncate">
                                {fragmentOf(t.object)}
                              </span>
                            </div>
                          ))}
                          {triples.length > 20 && (
                            <p className="text-xs text-muted-foreground px-2 py-1">
                              ...and {triples.length - 20} more
                            </p>
                          )}
                        </div>
                      </ScrollArea>
                    </DetailSection>
                  )
                })()}

                {/* Source */}
                <DetailSection label="Source Ontology">
                  <Badge variant="secondary" className="text-xs">
                    {selectedItem.ontologyName}
                  </Badge>
                </DetailSection>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}

// --- Sub-components ---

function DetailSection({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        {label}
      </span>
      {children}
    </div>
  )
}

function DefinitionCard({
  item,
  query,
  onClick,
}: {
  item: DefinitionItem
  query: string
  onClick: () => void
}) {
  return (
    <Card
      className="cursor-pointer transition-all hover:border-primary/30 hover:shadow-sm hover:shadow-primary/5"
      onClick={onClick}
    >
      <CardContent className="flex flex-col gap-2.5 p-4">
        <div className="flex items-start gap-3">
          <div
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md border ${
              item.kind === "class" ? "bg-primary/10 border-primary/20" : "bg-chart-2/10 border-chart-2/20"
            }`}
          >
            {item.kind === "class" ? (
              <Layers className="h-3.5 w-3.5 text-primary" />
            ) : (
              <GitBranch className="h-3.5 w-3.5 text-chart-2" />
            )}
          </div>
          <div className="flex flex-col gap-0.5 min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-semibold text-foreground">
                <Highlight text={item.label} query={query} />
              </span>
              <Badge variant="outline" className="text-xs">
                {item.kind === "class" ? "Class" : "Property"}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
              <Highlight text={item.description} query={query} />
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-1 border-t border-border/50">
          <span className="text-xs font-mono text-muted-foreground/60 truncate max-w-48">
            {fragmentOf(item.uri)}
          </span>
          <Badge variant="secondary" className="text-xs font-normal shrink-0">
            {item.ontologyName}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}

function fragmentOf(uri: string) {
  if (uri.includes("#")) return uri.split("#").pop() || uri
  return uri.split("/").pop() || uri
}

function Highlight({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>
  const q = query.trim()
  const idx = text.toLowerCase().indexOf(q.toLowerCase())
  if (idx === -1) return <>{text}</>
  return (
    <>
      {text.slice(0, idx)}
      <mark className="bg-primary/25 text-foreground rounded-sm px-0.5">{text.slice(idx, idx + q.length)}</mark>
      {text.slice(idx + q.length)}
    </>
  )
}
