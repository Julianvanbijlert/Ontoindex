"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { SiteHeader } from "@/components/site-header"
import {
  useOntologyStore,
  type OntologyEntry,
  type OntologyClass,
  type OntologyProperty,
  type OntologyTriple,
} from "@/lib/ontology-store"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Search,
  Upload,
  Layers,
  GitBranch,
  Database,
  FileText,
  ArrowRight,
  X,
  Filter,
} from "lucide-react"

type SearchCategory = "all" | "classes" | "properties" | "triples"

// Flattened item types for search results
type ClassResult = OntologyClass & { ontologyId: string; ontologyName: string }
type PropertyResult = OntologyProperty & { ontologyId: string; ontologyName: string }
type TripleResult = OntologyTriple & { ontologyId: string; ontologyName: string; index: number }

export default function SearchPage() {
  const { ontologies } = useOntologyStore()
  const [query, setQuery] = useState("")
  const [category, setCategory] = useState<SearchCategory>("all")
  const [sourceFilter, setSourceFilter] = useState("all")
  const [propertyTypeFilter, setPropertyTypeFilter] = useState<"all" | "object" | "data">("all")

  // Flatten all ontology contents into searchable lists
  const allClasses = useMemo<ClassResult[]>(() => {
    return ontologies.flatMap((o) =>
      (o.classes || []).map((c) => ({ ...c, ontologyId: o.id, ontologyName: o.name }))
    )
  }, [ontologies])

  const allProperties = useMemo<PropertyResult[]>(() => {
    return ontologies.flatMap((o) =>
      (o.properties || []).map((p) => ({ ...p, ontologyId: o.id, ontologyName: o.name }))
    )
  }, [ontologies])

  const allTriples = useMemo<TripleResult[]>(() => {
    return ontologies.flatMap((o) =>
      (o.triples || []).map((t, i) => ({ ...t, ontologyId: o.id, ontologyName: o.name, index: i }))
    )
  }, [ontologies])

  // Filtered results
  const filteredClasses = useMemo(() => {
    const q = query.toLowerCase().trim()
    return allClasses.filter((c) => {
      if (sourceFilter !== "all" && c.ontologyId !== sourceFilter) return false
      if (!q) return true
      return [c.uri, c.label, c.description, c.parentClass].join(" ").toLowerCase().includes(q)
    })
  }, [allClasses, query, sourceFilter])

  const filteredProperties = useMemo(() => {
    const q = query.toLowerCase().trim()
    return allProperties.filter((p) => {
      if (sourceFilter !== "all" && p.ontologyId !== sourceFilter) return false
      if (propertyTypeFilter !== "all" && p.type !== propertyTypeFilter) return false
      if (!q) return true
      return [p.uri, p.label, p.domain, p.range, p.type].join(" ").toLowerCase().includes(q)
    })
  }, [allProperties, query, sourceFilter, propertyTypeFilter])

  const filteredTriples = useMemo(() => {
    const q = query.toLowerCase().trim()
    return allTriples.filter((t) => {
      if (sourceFilter !== "all" && t.ontologyId !== sourceFilter) return false
      if (!q) return true
      return [t.subject, t.predicate, t.object].join(" ").toLowerCase().includes(q)
    })
  }, [allTriples, query, sourceFilter])

  const totalResults =
    category === "classes"
      ? filteredClasses.length
      : category === "properties"
      ? filteredProperties.length
      : category === "triples"
      ? filteredTriples.length
      : filteredClasses.length + filteredProperties.length + filteredTriples.length

  const hasActiveFilters = query !== "" || sourceFilter !== "all" || propertyTypeFilter !== "all"

  const clearFilters = () => {
    setQuery("")
    setSourceFilter("all")
    setPropertyTypeFilter("all")
  }

  const hasOntologies = ontologies.length > 0

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 py-8">
        <div className="flex flex-col gap-6">
          {/* Page Header */}
          <div>
            <h2 className="text-2xl font-semibold text-foreground tracking-tight text-balance">
              Search Ontology Contents
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Search across triples, classes, and properties from all uploaded ontologies.
            </p>
          </div>

          {!hasOntologies ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary">
                  <Upload className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="mt-4 text-sm font-medium text-foreground">
                  No ontologies uploaded yet
                </p>
                <p className="mt-1 text-xs text-muted-foreground text-center max-w-sm">
                  Upload ontology files first, then come back here to search through their classes, properties, and triples.
                </p>
                <Button asChild variant="outline" size="sm" className="mt-4">
                  <Link href="/">Go to Upload</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Search + Filters */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col gap-4">
                    <div className="relative">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search URIs, labels, subjects, predicates, objects..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        className="bg-secondary/50 border-border pl-10 text-foreground placeholder:text-muted-foreground"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                        <Filter className="h-3.5 w-3.5" />
                        Filters
                      </div>

                      <Select value={sourceFilter} onValueChange={setSourceFilter}>
                        <SelectTrigger className="w-48 bg-secondary/50 border-border text-sm">
                          <SelectValue placeholder="All Ontologies" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Ontologies</SelectItem>
                          {ontologies.map((o) => (
                            <SelectItem key={o.id} value={o.id}>
                              {o.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      {(category === "all" || category === "properties") && (
                        <Select value={propertyTypeFilter} onValueChange={(v) => setPropertyTypeFilter(v as "all" | "object" | "data")}>
                          <SelectTrigger className="w-40 bg-secondary/50 border-border text-sm">
                            <SelectValue placeholder="Property Type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                            <SelectItem value="object">Object Property</SelectItem>
                            <SelectItem value="data">Data Property</SelectItem>
                          </SelectContent>
                        </Select>
                      )}

                      {hasActiveFilters && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={clearFilters}
                          className="gap-1 text-xs text-muted-foreground hover:text-foreground"
                        >
                          <X className="h-3 w-3" />
                          Clear
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Stats Bar */}
              <div className="flex flex-wrap items-center gap-4">
                <StatChip icon={<FileText className="h-3.5 w-3.5" />} label="Source Ontologies" value={ontologies.length} />
                <StatChip icon={<Layers className="h-3.5 w-3.5" />} label="Classes" value={filteredClasses.length} />
                <StatChip icon={<GitBranch className="h-3.5 w-3.5" />} label="Properties" value={filteredProperties.length} />
                <StatChip icon={<Database className="h-3.5 w-3.5" />} label="Triples" value={filteredTriples.length} />
                <div className="ml-auto text-xs text-muted-foreground">
                  {totalResults} result{totalResults !== 1 ? "s" : ""}
                </div>
              </div>

              {/* Tabbed Results */}
              <Tabs value={category} onValueChange={(v) => setCategory(v as SearchCategory)}>
                <TabsList>
                  <TabsTrigger value="all" className="gap-1.5 text-xs">
                    All ({filteredClasses.length + filteredProperties.length + filteredTriples.length})
                  </TabsTrigger>
                  <TabsTrigger value="classes" className="gap-1.5 text-xs">
                    <Layers className="h-3.5 w-3.5" />
                    Classes ({filteredClasses.length})
                  </TabsTrigger>
                  <TabsTrigger value="properties" className="gap-1.5 text-xs">
                    <GitBranch className="h-3.5 w-3.5" />
                    Properties ({filteredProperties.length})
                  </TabsTrigger>
                  <TabsTrigger value="triples" className="gap-1.5 text-xs">
                    <Database className="h-3.5 w-3.5" />
                    Triples ({filteredTriples.length})
                  </TabsTrigger>
                </TabsList>

                <div className="mt-4 flex flex-col gap-2">
                  <TabsContent value="all" className="mt-0 flex flex-col gap-4">
                    {filteredClasses.length > 0 && (
                      <ResultSection title="Classes" count={filteredClasses.length}>
                        {filteredClasses.slice(0, 10).map((c) => (
                          <ClassRow key={`${c.ontologyId}-${c.uri}`} item={c} query={query} />
                        ))}
                        {filteredClasses.length > 10 && (
                          <button
                            onClick={() => setCategory("classes")}
                            className="flex items-center gap-1 px-4 py-2 text-xs text-primary hover:underline"
                          >
                            View all {filteredClasses.length} classes
                            <ArrowRight className="h-3 w-3" />
                          </button>
                        )}
                      </ResultSection>
                    )}
                    {filteredProperties.length > 0 && (
                      <ResultSection title="Properties" count={filteredProperties.length}>
                        {filteredProperties.slice(0, 10).map((p) => (
                          <PropertyRow key={`${p.ontologyId}-${p.uri}`} item={p} query={query} />
                        ))}
                        {filteredProperties.length > 10 && (
                          <button
                            onClick={() => setCategory("properties")}
                            className="flex items-center gap-1 px-4 py-2 text-xs text-primary hover:underline"
                          >
                            View all {filteredProperties.length} properties
                            <ArrowRight className="h-3 w-3" />
                          </button>
                        )}
                      </ResultSection>
                    )}
                    {filteredTriples.length > 0 && (
                      <ResultSection title="Triples" count={filteredTriples.length}>
                        {filteredTriples.slice(0, 15).map((t) => (
                          <TripleRow key={`${t.ontologyId}-${t.index}`} item={t} query={query} />
                        ))}
                        {filteredTriples.length > 15 && (
                          <button
                            onClick={() => setCategory("triples")}
                            className="flex items-center gap-1 px-4 py-2 text-xs text-primary hover:underline"
                          >
                            View all {filteredTriples.length} triples
                            <ArrowRight className="h-3 w-3" />
                          </button>
                        )}
                      </ResultSection>
                    )}
                    {totalResults === 0 && <NoResults hasFilters={hasActiveFilters} onClear={clearFilters} />}
                  </TabsContent>

                  <TabsContent value="classes" className="mt-0 flex flex-col gap-2">
                    {filteredClasses.length === 0 ? (
                      <NoResults hasFilters={hasActiveFilters} onClear={clearFilters} />
                    ) : (
                      filteredClasses.map((c) => (
                        <ClassRow key={`${c.ontologyId}-${c.uri}`} item={c} query={query} />
                      ))
                    )}
                  </TabsContent>

                  <TabsContent value="properties" className="mt-0 flex flex-col gap-2">
                    {filteredProperties.length === 0 ? (
                      <NoResults hasFilters={hasActiveFilters} onClear={clearFilters} />
                    ) : (
                      filteredProperties.map((p) => (
                        <PropertyRow key={`${p.ontologyId}-${p.uri}`} item={p} query={query} />
                      ))
                    )}
                  </TabsContent>

                  <TabsContent value="triples" className="mt-0 flex flex-col gap-2">
                    {filteredTriples.length === 0 ? (
                      <NoResults hasFilters={hasActiveFilters} onClear={clearFilters} />
                    ) : (
                      filteredTriples.map((t) => (
                        <TripleRow key={`${t.ontologyId}-${t.index}`} item={t} query={query} />
                      ))
                    )}
                  </TabsContent>
                </div>
              </Tabs>
            </>
          )}
        </div>
      </main>
    </div>
  )
}

// --- Highlight helper ---

function Highlight({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>
  const q = query.trim()
  const idx = text.toLowerCase().indexOf(q.toLowerCase())
  if (idx === -1) return <>{text}</>
  return (
    <>
      {text.slice(0, idx)}
      <mark className="bg-primary/25 text-foreground rounded-sm px-0.5">{text.slice(idx, idx + q.length)}</mark>
      {text.slice(idx + q.length)}
    </>
  )
}

// --- Compact URI display ---

function CompactUri({ uri, query }: { uri: string; query: string }) {
  // Show just the fragment or last path segment
  const fragment = uri.includes("#") ? uri.split("#").pop() : uri.split("/").pop()
  return (
    <span className="font-mono text-xs" title={uri}>
      <Highlight text={fragment || uri} query={query} />
    </span>
  )
}

// --- Result Section wrapper ---

function ResultSection({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2 px-1">
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        <Badge variant="secondary" className="text-xs">{count}</Badge>
      </div>
      {children}
    </div>
  )
}

// --- Class Row ---

function ClassRow({ item, query }: { item: ClassResult; query: string }) {
  const parentFragment = item.parentClass.includes("#")
    ? item.parentClass.split("#").pop()
    : item.parentClass.split("/").pop()

  return (
    <Card className="transition-colors hover:border-primary/30">
      <CardContent className="flex items-start gap-4 py-3 px-4">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary/10 border border-primary/20 mt-0.5">
          <Layers className="h-3.5 w-3.5 text-primary" />
        </div>
        <div className="flex flex-1 flex-col gap-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-foreground">
              <Highlight text={item.label} query={query} />
            </span>
            <Badge variant="outline" className="text-xs">Class</Badge>
            <Badge variant="secondary" className="text-xs font-normal">
              {item.ontologyName}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            <Highlight text={item.description} query={query} />
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground mt-0.5">
            <span>
              URI: <span className="font-mono text-foreground/70"><Highlight text={item.uri} query={query} /></span>
            </span>
            {parentFragment && parentFragment !== "Thing" && (
              <span>
                Parent: <span className="font-mono text-foreground/70">{parentFragment}</span>
              </span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// --- Property Row ---

function PropertyRow({ item, query }: { item: PropertyResult; query: string }) {
  const domainFrag = item.domain.includes("#") ? item.domain.split("#").pop() : item.domain.split("/").pop()
  const rangeFrag = item.range.includes("#") ? item.range.split("#").pop() : item.range.split("/").pop()

  return (
    <Card className="transition-colors hover:border-primary/30">
      <CardContent className="flex items-start gap-4 py-3 px-4">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-chart-2/10 border border-chart-2/20 mt-0.5">
          <GitBranch className="h-3.5 w-3.5 text-chart-2" />
        </div>
        <div className="flex flex-1 flex-col gap-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-foreground">
              <Highlight text={item.label} query={query} />
            </span>
            <Badge
              variant="outline"
              className={
                item.type === "object"
                  ? "text-xs border-chart-2/40 text-chart-2"
                  : "text-xs border-chart-4/40 text-chart-4"
              }
            >
              {item.type === "object" ? "Object Property" : "Data Property"}
            </Badge>
            <Badge variant="secondary" className="text-xs font-normal">
              {item.ontologyName}
            </Badge>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span className="font-mono text-foreground/70">{domainFrag}</span>
            <ArrowRight className="h-3 w-3 text-muted-foreground/50" />
            <span className="font-mono text-foreground/70">{rangeFrag}</span>
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            URI: <span className="font-mono text-foreground/70"><Highlight text={item.uri} query={query} /></span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// --- Triple Row ---

function TripleRow({ item, query }: { item: TripleResult; query: string }) {
  return (
    <Card className="transition-colors hover:border-primary/30">
      <CardContent className="flex items-start gap-4 py-3 px-4">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-chart-3/10 border border-chart-3/20 mt-0.5">
          <Database className="h-3.5 w-3.5 text-chart-3" />
        </div>
        <div className="flex flex-1 flex-col gap-1.5 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-xs">Triple</Badge>
            <Badge variant="secondary" className="text-xs font-normal">
              {item.ontologyName}
            </Badge>
          </div>
          <div className="flex flex-col gap-1 rounded-md bg-secondary/40 border border-border px-3 py-2 font-mono text-xs">
            <div className="flex items-start gap-2">
              <span className="text-muted-foreground w-10 shrink-0">S</span>
              <span className="text-foreground/90 break-all">
                <CompactUri uri={item.subject} query={query} />
              </span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-muted-foreground w-10 shrink-0">P</span>
              <span className="text-primary/80 break-all">
                <CompactUri uri={item.predicate} query={query} />
              </span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-muted-foreground w-10 shrink-0">O</span>
              <span className="text-foreground/90 break-all">
                <Highlight text={item.object} query={query} />
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// --- No Results ---

function NoResults({ hasFilters, onClear }: { hasFilters: boolean; onClear: () => void }) {
  return (
    <Card>
      <CardContent className="flex flex-col items-center justify-center py-12">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary">
          <Search className="h-5 w-5 text-muted-foreground" />
        </div>
        <p className="mt-3 text-sm font-medium text-foreground">No results found</p>
        <p className="mt-1 text-xs text-muted-foreground">
          {hasFilters ? "Try adjusting your search or filters." : "Search for classes, properties, or triples."}
        </p>
        {hasFilters && (
          <Button variant="outline" size="sm" className="mt-3" onClick={onClear}>
            Clear filters
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

// --- Stat Chip ---

function StatChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex items-center gap-2 rounded-md bg-card border border-border px-3 py-2">
      <span className="text-primary">{icon}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-semibold text-foreground">{value}</span>
    </div>
  )
}
